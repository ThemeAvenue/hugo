<?php
/**
 * Behance Portfolio plugin for WordPress
 *
 * @package   Behance Portfolio
 * @author 	  ThemeAvenue <web@themeavenue.net>
 * @license   GPL-2.0+
 * @link 	  http://themeavenue.net
 * @copyright 2014 ThemeAvenue
 * 
 * Plugin Name: Behance Portfolio
 * Plugin URI: http://themeavenue.net/
 * Description: Behance Portfolio for WordPress lets you showcase your Behance items on your site without having to manually add them one by one. The plugins takes advantage of the Behance API to gather all your projects.
 * Version: 2.0.4
 * Author: ThemeAvenue
 * Author URI: http://themeavenue.net/
 * License: GPL2
*/

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( ! class_exists( 'Behance_Portfolio' ) ):

	final class Behance_Portfolio {

		/**
		 * @var Behance_Portfolio Holds the unique instance of Awesome Support
		 * @since 2.0.0
		 */
		private static $instance;

		/**
		 * Holds the unique instance of the Behance API client
		 *
		 * @since 2.0
		 * @var object Behance\Client
		 */
		public static $client;

		/**
		 * Instantiate and return the unique Behance Portfolio object
		 *
		 * @since     2.0
		 * @return object Behance_Portfolio Unique instance of Behance Portfolio
		 */
		public static function instance() {

			if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Behance_Portfolio ) ) {
				self::$instance = new Behance_Portfolio;
				self::$instance->init();
			}

			return self::$instance;

		}

		/**
		 * Instantiate the plugin
		 *
		 * @since 2.0
		 * @return void
		 */
		private function init() {

			self::$instance->setup_constants();
			self::$instance->includes();

			if ( is_admin() ) {
				self::$instance->includes_admin();
				self::$instance->updater();
			}

			add_action( 'plugins_loaded', array( self::$instance, 'load_plugin_textdomain' ) );

		}

		/**
		 * Throw error on object clone
		 *
		 * The whole idea of the singleton design pattern is that there is a single
		 * object therefore, we don't want the object to be cloned.
		 *
		 * @since 2.0.0
		 * @return void
		 */
		public function __clone() {
			// Cloning instances of the class is forbidden
			_doing_it_wrong( __FUNCTION__, __( 'Cheatin&#8217; huh?', 'awesome-support' ), '3.2.5' );
		}

		/**
		 * Disable unserializing of the class
		 *
		 * @since 2.0.0
		 * @return void
		 */
		public function __wakeup() {
			// Unserializing instances of the class is forbidden
			_doing_it_wrong( __FUNCTION__, __( 'Cheatin&#8217; huh?', 'awesome-support' ), '3.2.5' );
		}

		/**
		 * Setup all plugin constants
		 *
		 * @since 2.0.0
		 * @return void
		 */
		private function setup_constants() {
			define( 'WPBP_VERSION', '2.0.4' );
			define( 'WPBP_URL', plugin_dir_url( __FILE__ ) );
			define( 'WPBP_PATH', plugin_dir_path( __FILE__ ) );
			define( 'WPBP_BASENAME', plugin_basename( __FILE__ ) );
			define( 'WPBP_PLUGIN_FILE', __FILE__ );
		}

		/**
		 * Load all required files
		 *
		 * @since 2.0
		 * @return void
		 */
		private function includes() {
			require( WPBP_PATH . 'vendor/autoload.php' );
			require( WPBP_PATH . 'includes/compatibility.php' );
			require( WPBP_PATH . 'includes/functions-misc.php' );
			require( WPBP_PATH . 'includes/functions-portfolio.php' );
			require( WPBP_PATH . 'includes/functions-tlc-transients.php' );
			require( WPBP_PATH . 'includes/class-wpbp-project.php' );
			require( WPBP_PATH . 'includes/scripts.php' );

			// Load all shortcodes
			require( WPBP_PATH . 'includes/shortcodes/portfolio.php' );
			require( WPBP_PATH . 'includes/shortcodes/filters.php' );
			require( WPBP_PATH . 'includes/shortcodes/sort.php' );
		}

		/**
		 * Load all required files in the admin
		 *
		 * @since 2.0
		 * @return void
		 */
		private function includes_admin() {

			// Call the license check functions
			require( WPBP_PATH . 'includes/admin/check-envato-license.php' );

			if ( ! defined( 'DOING_AJAX' ) || ! DOING_AJAX ) {

				require( WPBP_PATH . 'includes/admin/functions-settings.php' );
				require( WPBP_PATH . 'includes/admin/functions-rendering.php' );
				require( WPBP_PATH . 'includes/admin/functions-actions.php' );
				require( WPBP_PATH . 'includes/admin/functions-misc.php' );
				require( WPBP_PATH . 'includes/admin/functions-menu.php' );
				require( WPBP_PATH . 'includes/admin/settings.php' );
				require( WPBP_PATH . 'includes/install.php' );

				if ( ! class_exists( 'lessc' ) ) {
					require( WPBP_PATH . 'includes/lessc.inc.php' );
				}

			}

		}

		/**
		 * Helper method to get the updater data
		 *
		 * This is helpful for the license verification function that's done using Ajax.
		 *
		 * @since 2.0.3
		 *
		 * @param string $arg Config argument to retrieve
		 *
		 * @return string
		 */
		public function get_updater_config( $arg ) {

			$value  = '';
			$config = array(
					'repo_uri'  => 'https://api.themeavenue.net/',
					'repo_slug' => 'behance-portfolio',
			);

			if ( array_key_exists( $arg, $config ) ) {
				$value = $config[ $arg ];
			}

			return $value;

		}

		/**
		 * Handles plugin updates
		 *
		 * @since 1.0
		 * @return void
		 */
		private function updater() {

			// Plugin updater class
			require( WPBP_PATH . 'includes/plugin-updater.php' );

			// Updater config
			$wpbp_updater_config = array(
					'base'           => plugin_basename( __FILE__ ), //required
					'envato_license' => wpbp_get_option( 'wpbp_license', '' ),
					'repo_uri'       => self::$instance->get_updater_config( 'repo_uri' ),  //required
					'repo_slug'      => self::$instance->get_updater_config( 'repo_slug' ),  //required
			);

			// Instantiate the updater class
			new Behance_Portfolio_Plugin_Updater( $wpbp_updater_config );

		}

		/**
		 * Load the plugin text domain for translation.
		 *
		 * @since    1.0.0
		 */
		public function load_plugin_textdomain() {

			$language = false;
			$lang_path = WPBP_PATH . 'languages/';
			$locale    = apply_filters( 'plugin_locale', get_locale(), 'behance-portfolio' );
			$mofile    = "behance-portfolio-$locale.mo";

			if ( file_exists( $lang_path . $mofile ) ) {
				$language = load_textdomain( 'behance-portfolio', $lang_path . $mofile );
			}

			return $language;

		}

		/**
		 * Instantiate the Behance API object
		 *
		 * @since 2.0
		 * @return object Behance\Client
		 */
		public function client() {

			if ( empty( self::$client ) ) {
				$api_key      = trim( wpbp_get_option( 'behance_api_key' ) );
				self::$client = new Behance\Client( $api_key );
			}

			return self::$client;

		}

	}

endif;

/**
 * The main function responsible for returning the unique Behance Portfolio instance
 *
 * Use this function like you would a global variable, except without needing
 * to declare the global.
 *
 * @since 2.0
 * @return object Behance_Portfolio
 */
function WPBP() {
	return Behance_Portfolio::instance();
}

// Run the plugin
WPBP();