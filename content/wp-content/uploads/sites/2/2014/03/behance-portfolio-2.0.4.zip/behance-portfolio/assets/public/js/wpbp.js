/*global jQuery:false */
(function ($) {
	'use strict';

	// Reading WordPress Options
	var wpbpStr, wpbpObj;
	if (typeof wpbp !== 'undefined') {
		wpbpStr = wpbp.replace(/&quot;/g, '"');
		wpbpObj = $.parseJSON(wpbpStr);
	} else {
		wpbpObj = {
			anim: {
				entrance: 'flipInX',
				exit: 'fadeOut'
			},
			slider: {
				slideshow: true,
				slideshow_speed: 7000,
				animation: 'slide',
				pause: false
			}
		};
	}

	/////////////////////
	// Document Ready //
	/////////////////////
	$(function () {

		/*----------- Modal -----------*/
		if (jQuery().easyModal) {
			$('.ta-modal').easyModal({
				top: 200,
				overlay: 0.2,
				closeButtonClass: '.ta-modal-close',
				transitionIn: 'animated ' + wpbpObj.anim.entrance,
				transitionOut: 'animated ' + wpbpObj.anim.exit,
				updateZIndexOnOpen: false
			});
			$('.ta-modal-launch').click(function (e) {
				var target = $(this).attr('href');
				$(target).trigger('openModal');
				e.preventDefault();
			});
		}

		/*----------- Modal Slider -----------*/
		if (jQuery().responsiveSlides) {
			$('#wpbp-modal-slider').responsiveSlides({
				manualControls: '#wpbp-modal-slider-pager',
				maxwidth: 450,
				namespace: 'wpbp_slides',
				auto: true,
				speed: 500,
				timeout: 4000,
				random: false,
				pause: false,
			});
		}

		/*----------- Mixitup -----------*/
		if (jQuery().mixitup) {
			// Grid settings
			$('#wpbp-grid').mixitup({
				targetSelector: '.wpbp-mix',
				filterSelector: '.wpbp-filters .wpbp-label'
			});
			// Select Layout for filters
			$('.wpbe-filter-select').change(function () {
				var filter = $('option:selected', this).data('filter');
				$('#wpbp-grid').mixitup('filter', filter);
			});
		}

	});

	//////////////////
	// Window.load //
	//////////////////
	$(window).load(function () {
		if (jQuery().flexslider) {
			// The slider being synced must be initialized first
			var wpbpSlider = $('#wpbp-slider'),
				wpbpCarousel = $('#wpbp-carousel');

			wpbpSlider.flexslider({
				namespace: 'wpbp-',
				controlNav: false,
				directionNav: false,
				animationLoop: false,
				sync: wpbpCarousel,
				selector: '.wpbp-slides > div',
				animation: wpbpObj.slider.animation,
				pauseOnHover: wpbpObj.slider.pause,
				slideshow: wpbpObj.slider.slideshow,
				slideshowSpeed: wpbpObj.slider.slideshowSpeed
			});

			wpbpCarousel.flexslider({
				namespace: 'wpbp-',
				animation: 'slide',
				controlNav: false,
				animationLoop: false,
				slideshow: false,
				itemWidth: 210,
				itemMargin: 0,
				asNavFor: wpbpSlider,
				directionNav: false,
				selector: '.wpbp-slides > li'
			});

			$('.wpbp-prev').on('click', function () {
				wpbpSlider.flexslider('prev');
				return false;
			});

			$('.wpbp-next').on('click', function () {
				wpbpSlider.flexslider('next');
				return false;
			});
		}
	});

}(jQuery));