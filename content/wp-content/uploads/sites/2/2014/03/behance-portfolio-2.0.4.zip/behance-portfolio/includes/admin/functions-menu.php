<?php
/**
 * Behance Portfolio plugin for WordPress
 *
 * @package     Behance Portfolio
 * @author      ThemeAvenue <web@themeavenue.net>
 * @license     GPL-2.0+
 * @link        http://themeavenue.net
 * @copyright   2014 ThemeAvenue
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

add_action( 'admin_menu', 'wpbp_add_plugin_admin_menu' );
/**
 * Register the administration menu for this plugin into the WordPress Dashboard menu.
 *
 * @since    1.0.0
 */
function wpbp_add_plugin_admin_menu() {

	$icon = ( version_compare( get_bloginfo( 'version' ), '3.8', '>=' ) ) ? 'dashicons-format-gallery' : WPBP_URL . 'admin/assets/images/be-badge-small.png';

	add_menu_page( __( 'Behance Portfolio Settings', 'behance-portfolio' ), __( 'Be Portfolio', 'behance-portfolio' ), 'manage_options', 'wpbp-settings', 'wpbp_display_plugin_admin_page', $icon );
	add_submenu_page( 'wpbp-settings', __( 'Behance Portfolio Settings', 'behance-portfolio' ), __( 'Settings', 'behance-portfolio' ), 'manage_options', 'wpbp-settings', 'wpbp_display_plugin_admin_page' );
	add_submenu_page( 'wpbp-settings', __( 'About Page', 'behance-portfolio' ), __( 'About', 'behance-portfolio' ), 'manage_options', 'wpbp-about', 'wpbp_about_page' );
	add_submenu_page( 'wpbp-settings', __( 'Documentation', 'behance-portfolio' ), __( 'Documentation', 'behance-portfolio' ), 'manage_options', 'wpbp-docs', 'wpbp_docs_page' );

}

/**
 * Render the settings page for this plugin.
 *
 * @since    1.0.0
 */
function wpbp_display_plugin_admin_page() {
	include_once( WPBP_PATH . 'includes/admin/views/admin.php' );
}

/**
 * Render the about page
 *
 * @since 1.0.1
 */
function wpbp_about_page() {
	require_once( WPBP_PATH . 'includes/admin/views/about.php' );
}

/**
 * Render the documentation page
 *
 * @since 1.0.1
 */
function wpbp_docs_page() {
	require_once( WPBP_PATH . 'includes/admin/views/docs.php' );
}

add_filter( 'plugin_action_links_' . WPBP_BASENAME, 'wpbp_add_action_links' );
/**
 * Add settings action link to the plugins page.
 *
 * @since    1.0.0
 */
function wpbp_add_action_links( $links ) {

	return array_merge(
			array(
					'settings' => '<a href="' . admin_url( 'options-general.php?page=wpbp-settings' ) . '">' . __( 'Settings', 'behance-portfolio' ) . '</a>'
			),
			$links
	);

}

add_filter( 'plugin_row_meta', 'wpbp_add_meta_link', 10, 4 );
/**
 * Add license warning in the plugin meta row
 *
 * @since 1.0.0
 *
 * @param array  $plugin_meta The plugin metas
 * @param string $plugin_file The plugin basename
 * @param array  $plugin_data Plugin data
 * @param string $status      Plugin status
 *
 * @return array Updated metas
 */
function wpbp_add_meta_link( $plugin_meta, $plugin_file, $plugin_data, $status ) {

	$license = wpbp_get_option( 'wpbp_license', false );

	if ( $license ) {
		return $plugin_meta;
	}

	if ( WPBP_BASENAME == $plugin_file ) {
		$plugin_meta[] = '<strong>' . __( 'You must set your Envato purchase code in order to update the plugin', 'behance-portfolio' ) . '</strong>';
	}

	return $plugin_meta;

}