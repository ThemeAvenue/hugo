<?php
/**
 * Behance Portfolio plugin for WordPress
 *
 * @package     Behance Portfolio
 * @author      ThemeAvenue <web@themeavenue.net>
 * @license     GPL-2.0+
 * @link        http://themeavenue.net
 * @copyright   2014 ThemeAvenue
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

add_action( 'init', 'wpbp_register_post_type' );
/**
 * Register portfolio post type
 *
 * When the plugin is used in full mode, this post type
 * is used to synchronize and store the Behance portfolio
 * items.
 */
function wpbp_register_post_type() {

	$labels = array(
		'name'               => __( 'Be Portfolio', 'behance-portfolio' ),
		'singular_name'      => __( 'Portfolio', 'behance-portfolio' ),
		'add_new'            => __( 'Add Item', 'behance-portfolio' ),
		'add_new_item'       => __( 'Add New Item', 'behance-portfolio' ),
		'edit_item'          => __( 'Edit Item', 'behance-portfolio' ),
		'new_item'           => __( 'New Item', 'behance-portfolio' ),
		'all_items'          => __( 'All Items', 'behance-portfolio' ),
		'view_item'          => __( 'View Item', 'behance-portfolio' ),
		'search_items'       => __( 'Search Items', 'behance-portfolio' ),
		'not_found'          => __( 'No Item Found', 'behance-portfolio' ),
		'not_found_in_trash' => __( 'No items in the trash', 'behance-portfolio' ),
		'parent_item_colon'  => '',
		'menu_name'          => __( 'Be Portfolio', 'behance-portfolio' )
	);

	$args = array(
		'labels'             => $labels,
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => $this->plugin_slug ),
		'capability_type'    => 'post',
		'capabilities'       => array(
			'edit_post'          => 'edit_posts',
			'read_post'          => 'edit_posts',
			'delete_post'        => 'no_can_do',
			'edit_posts'         => 'edit_posts',
			'edit_others_posts'  => 'edit_posts',
			'publish_posts'      => 'no_can_do',
			'read_private_posts' => 'edit_posts'
		),
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => null,
		'supports'           => array( 'title', 'editor', 'comments' )
	);

	register_post_type( 'wpbp-portfolio', $args );
}