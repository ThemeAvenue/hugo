(function ($) {
	'use strict';

	$(function () {
		// Create Summary
		$('h2,h3').each(function (index) {
			var position = index + 1,
				heading = $(this).text(),
				headingText = $('<li><a href="#ta-doc-' + position + '">' + heading + '</a></li>');
			$(this).attr('id', 'ta-doc-' + position).append(' <a href="#top" class="wpbp-back-top" title="Back to the summary">&#9650;</span></a>');
			$('#ta-summary').show();
			$('#ta-summary > ol').append(headingText);
		});

		// Back to top
		$(document).on('click', '.wpbp-back-top', function (event) {
			event.preventDefault();
			$('html, body').animate({
				scrollTop: 0
			}, 400);
			return false;
		});

		// Smooth Scrolling
		$('a[href*=#]:not([href=#])').click(function () {
			if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
				var target = $(this.hash);
				target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
				if (target.length) {
					$('html,body').animate({
						scrollTop: target.offset().top - 50
					}, 600);
					$('.ta-highlight').removeClass('ta-highlight');
					target.addClass('ta-highlight');
					return false;
				}
			}
		});

		// Open External Links In New Window
		$('.about-wrap a[href^="http://"]').attr('target', '_blank');
	});

}(jQuery));