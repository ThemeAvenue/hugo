<?php
function wpbp_get_plugin_options() {

	$options = array(
		array(
			'id' 		=> 'wpbp_settings',
			'title' 	=> __('Plugin Validation', 'behance-portfolio'),
			'options' 	=> array(
				array(
					'id'		=> 'wpbp_license',
					'title'		=> __( 'Envato License', 'behance-portfolio' ),
					'desc' 		=> sprintf( __( 'If you want to be able to update the plugin, please provide your Envato purchase code. Otherwise the plugin WILL NEVER be updated. %sClick here if you don\'t know where to find your license code%s.', 'behance-portfolio' ), '<a href="//www.youtube.com/embed/5RGqrtx8ed4?rel=0&theme=light&modestbranding=1&autoplay=1&vq=hd1080" class="tav-trigger-modal" title="' . __( 'Find your Envato purchase code', 'behance-portfolio' ) . '">', '</a>' ),
					'type' 		=> 'license',
				),				
			),
		),
		array(
			'id' 		=> 'wpbp_account',
			'title' 	=> __('Behance Account', 'behance-portfolio'),
			'options' 	=> array(
				array(
					'id'		=> 'behance_username',
					'title'		=> __( 'Behance Username', 'behance-portfolio' ),
					'desc' 		=> __( 'Please provide your Behance username.', 'behance-portfolio' ),
					'type' 		=> 'text',
				),
				array(
					'id'		=> 'behance_api_key',
					'title'		=> __( 'Behance API Key', 'behance-portfolio' ),
					'desc' 		=> sprintf( __( 'If you don\'t have an API key yet, you must register an app in order to get API key and secret. <a href="%s" target="_blank">Register here</a>.', 'behance-portfolio' ), 'http://www.behance.net/dev/register' ),
					'type' 		=> 'text',
				),
			),
		),
		array(
			'id' 		=> 'wpbp_mode',
			'title' 	=> __('General Settings', 'behance-portfolio'),
			'options' 	=> array(
				array(
					'id'		=> 'cache',
					'title'		=> __( 'Caching', 'behance-portfolio' ),
					'desc' 		=> __( 'If you use the light mode, the plugin will cache the Behance data in order to reduce the number of requests on the API. Please specify the caching delay (must be in hours).', 'behance-portfolio' ),
					'type' 		=> 'numeric',
				),
				array(
					'id'		=> 'items_max',
					'title'		=> __( 'Items Limit', 'behance-portfolio' ),
					'desc' 		=> __( 'You can set a maximum number of items to display.', 'behance-portfolio' ),
					'type' 		=> 'numeric',
				),
			)
		),
		array(
			'id' 		=> 'wpbp_colors',
			'title' 	=> __('Colors', 'behance-portfolio'),
			'options' 	=> array(
				array(
					'id'		=> 'color_primary',
					'title'		=> __('Primary Color', 'behance-portfolio'),
					'type' 		=> 'colorpicker',
				),
				array(
					'id'		=> 'color_secondary',
					'title'		=> __('Secondary Color', 'behance-portfolio'),
					'type' 		=> 'colorpicker',
				),
				array(
					'id'		=> 'color_light',
					'title'		=> __('Light Color', 'behance-portfolio'),
					'type' 		=> 'colorpicker',
				),
				array(
					'id'		=> 'color_hover',
					'title'		=> __('Hover Color', 'behance-portfolio'),
					'type' 		=> 'colorpicker',
				),
			)
		),
		array(
			'id' 		=> 'wpbp_layout',
			'title' 	=> __('Layout &amp; Style', 'behance-portfolio'),
			'options' 	=> array(
				array(
					'id'		=> 'layout_archive',
					'title'		=> __('Portfolio Layout', 'behance-portfolio'),
					'type' 		=> 'radio',
					'opts' 		=> array(
						'grid' => __( 'Grid', 'behance-portfolio' ),
						'slider' => __( 'Slider', 'behance-portfolio' )
					)
				),
				array(
					'id'		=> 'grid_gutters',
					'title'		=> __('Grid Gutters', 'behance-portfolio'),
					'desc' 		=> sprintf( __( 'If you use the grid layout and want to add gutters, please specify the size in %s (or leave %s for no gutters).', 'behance-portfolio' ), '<code>px</code>', '<code>0</code>' ),
					'type' 		=> 'numeric',
				),
				array(
					'id'		=> 'filters',
					'title'		=> __('Filters', 'behance-portfolio'),
					'desc' 		=> sprintf( __( 'Will allow user to filter items based on the Behance creative fields. If you set filters as "Manual", you can add filters manually by using the shortcode %s', 'behance-portfolio' ),  '<code>[wpbp-filters nav=&quot;labels&quot;]</code>' ),
					'type' 		=> 'radio',
					'opts' 		=> array(
						'labels' 			=> __( 'Badges', 'behance-portfolio' ),
						'select' 			=> __( 'Select Dropdown', 'behance-portfolio' ),
						'manual' 			=> sprintf( 'Manual', 'behance-portfolio' ),
					)
				),
				array(
					'id'		=> 'filters_position',
					'title'		=> __('Filters Position', 'behance-portfolio'),
					'type' 		=> 'radio',
					'opts' 		=> array(
						'left' 				=> __( 'Left', 'behance-portfolio' ),
						'center' 			=> __( 'Center', 'behance-portfolio' ),
						'right' 			=> __( 'Right', 'behance-portfolio' ),
						'justified' 		=> __( 'Justified', 'behance-portfolio' ),
					)
				),
				array(
					'id'		=> 'thumbnail_hover',
					'title'		=> __( 'Thumbnail Hover Effect', 'behance-portfolio' ),
					'desc' 		=> sprintf( __( 'To preview all the effects, %splease look at our demo%s.', 'behance-portfolio' ), '<a href="http://tympanus.net/Tutorials/CaptionHoverEffects/index.html" target="_blank">', '</a>' ),
					'type' 		=> 'dropdown',
					'opts' 		=> array(
						'1' => __( '1 - Fade Caption\'s overlay', 'behance-portfolio' ),
						'2' => __( '2 - Move Image Up to Reveal Caption', 'behance-portfolio' ),
						'3' => __( '3 - Slide Caption from Bottom', 'behance-portfolio' ),
						'4' => __( '4 - Flip Caption from Left', 'behance-portfolio' ),
						'5' => __( '5 - Image Shrink and Center', 'behance-portfolio' ),
						'6' => __( '6 - Image Shrink and Move up', 'behance-portfolio' ),
						'8' => __( '7 - Color to Grayscale', 'behance-portfolio' ),
						'9' => __( '8 - Grayscale to Color', 'behance-portfolio' ),
					)
				),
				array(
					'id'		=> 'button_label',
					'title'		=> __( 'Details Button Label', 'behance-portfolio' ),
					'desc' 		=> __( 'Label of the button visitors will click to see project\'s details.', 'behance-portfolio' ),
					'type' 		=> 'text',
				),
			)
		),
		array(
			'id' 		=> 'modal_design',
			'title' 	=> __( 'Popup Style (for grid layout)', 'behance-portfolio' ),
			'options' 	=> array(
				array(
					'id'		=> 'popup_animation_in',
					'title'		=> __('Popup Animation In', 'behance-portfolio'),
					'desc' 		=> sprintf( __( 'To preview all the effects, %splease visit this page%s.', 'behance-portfolio' ), '<a href="http://daneden.github.io/animate.css/" target="_blank">', '</a>' ),
					'type' 		=> 'dropdown',
					'opts' 		=> array(
						'bounceIn' => 'bounceIn',
						'bounceInDown' => 'bounceInDown',
						'bounceInLeft' => 'bounceInLeft',
						'bounceInRight' => 'bounceInRight',
						'bounceInUp' => 'bounceInUp',
						'fadeIn' => 'fadeIn',
						'fadeInDown' => 'fadeInDown',
						'fadeInDownBig' => 'fadeInDownBig',
						'fadeInLeft' => 'fadeInLeft',
						'fadeInLeftBig' => 'fadeInLeftBig',
						'fadeInRight' => 'fadeInRight',
						'fadeInRightBig' => 'fadeInRightBig',
						'fadeInUp' => 'fadeInUp',
						'fadeInUpBig' => 'fadeInUpBig',
						'rotateIn' => 'rotateIn',
						'rotateInDownLeft' => 'rotateInDownLeft',
						'rotateInDownRight' => 'rotateInDownRight',
						'rotateInUpLeft' => 'rotateInUpLeft',
						'rotateInUpRight' => 'rotateInUpRight',
						'slideInLeft' => 'slideInLeft',
						'slideInRight' => 'slideInRight',
						'slideInDown' => 'slideInDown',
						'rollIn' => 'rollIn',
						'flipInX' => 'flipInX',
						'flipInY' => 'flipInY',
						'lightSpeedIn' => 'lightSpeedIn',
					)
				),
				array(
					'id'		=> 'popup_animation_out',
					'title'		=> __('Popup Animation Out', 'behance-portfolio'),
					'desc' 		=> sprintf( __( 'To preview all the effects, %splease visit this page%s.', 'behance-portfolio' ), '<a href="http://daneden.github.io/animate.css/" target="_blank">', '</a>' ),
					'type' 		=> 'dropdown',
					'opts' 		=> array(
						'bounceOut' => 'bounceOut',
						'bounceOutDown' => 'bounceOutDown',
						'bounceOutLeft' => 'bounceOutLeft',
						'bounceOutRight' => 'bounceOutRight',
						'bounceOutUp' => 'bounceOutUp',
						'fadeOut' => 'fadeOut',
						'fadeOutDown' => 'fadeOutDown',
						'fadeOutDownBig' => 'fadeOutDownBig',
						'fadeOutLeft' => 'fadeOutLeft',
						'fadeOutLeftBig' => 'fadeOutLeftBig',
						'fadeOutRight' => 'fadeOutRight',
						'fadeOutRightBig' => 'fadeOutRightBig',
						'fadeOutUp' => 'fadeOutUp',
						'fadeOutUpBig' => 'fadeOutUpBig',
						'rotateOut' => 'rotateOut',
						'rotateOutDownLeft' => 'rotateOutDownLeft',
						'rotateOutDownRight' => 'rotateOutDownRight',
						'rotateOutUpLeft' => 'rotateOutUpLeft',
						'rotateOutUpRight' => 'rotateOutUpRight',
						'slideOutLeft' => 'slideOutLeft',
						'slideOutRight' => 'slideOutRight',
						'slideOutUp' => 'slideOutUp',
						'rollOut' => 'rollOut',
						'flipOutX' => 'flipOutX',
						'flipOutY' => 'flipOutY',
						'lightSpeedOut' => 'lightSpeedOut',
					)
				),
			)
		),
		array(
			'id' 		=> 'slider',
			'title' 	=> __( 'Slider Options (for slider layout)', 'behance-portfolio' ),
			'options' 	=> array(
				array(
					'id'		=> 'slider_thumbnails',
					'title'		=> __('Use Thumbnail Navigation', 'behance-portfolio'),
					'type' 		=> 'radio',
					'opts' 		=> array(
						'yes' => __( 'Yes', 'behance-portfolio' ),
						'no'  => __( 'No', 'behance-portfolio' ),
					)
				),
				array(
					'id'		=> 'slider_slideshow',
					'title'		=> __('Slider Auto Start', 'behance-portfolio'),
					'desc' 		=> __( 'Should the slider start sliding once the page is loaded?', 'behance-portfolio' ),
					'type' 		=> 'radio',
					'opts' 		=> array(
						'yes' => __( 'Yes', 'behance-portfolio' ),
						'no'  => __( 'No', 'behance-portfolio' ),
					)
				),
				array(
					'id'		=> 'slider_slideshow_speed',
					'title'		=> __('Slideshow Speed', 'behance-portfolio'),
					'desc' 		=> sprintf( __( 'Set the speed of the slideshow cycling, in %s (default 7000)', 'behance-portfolio' ), '<code>milliseconds</code>' ),
					'type' 		=> 'numeric',
				),
				array(
					'id'		=> 'slider_animation',
					'title'		=> __('Sliding Animation', 'behance-portfolio'),
					'type' 		=> 'dropdown',
					'opts' 		=> array(
						'slide' => __( 'Slide', 'behance-portfolio' ),
						'fade'  => __( 'Fade', 'behance-portfolio' ),
					)
				),
				array(
					'id'		=> 'slider_pause',
					'title'		=> __('Pause on Hover', 'behance-portfolio'),
					'type' 		=> 'radio',
					'opts' 		=> array(
						'yes' => __( 'Yes', 'behance-portfolio' ),
						'no'  => __( 'No', 'behance-portfolio' ),
					)
				),
			)
		),
		array(
			'id' 		=> 'elements',
			'title' 	=> __( 'Project Information', 'behance-portfolio' ),
			'options' 	=> array(
				array(
					'id'		=> 'items_elements',
					'title'		=> __( 'Elements to Show', 'behance-portfolio' ),
					'desc' 		=> sprintf( __( 'To see what elements you can show/hide, %sclick here%s.', 'behance-portfolio' ), '<a href="' . WPBP_URL . 'assets/admin/images/wpbp-modal.jpg" class="tav-trigger-modal" title="' . __( 'Popup Elements', 'behance-portfolio' ) . '">', '</a>' ),
					'type' 		=> 'checkbox',
					'opts' 		=> array(
						'subtitle' => __( 'Subtitle (creative fields)', 'behance-portfolio' ),
						'tags' 	   => __( 'Tags', 'behance-portfolio' ),
						'stats'    => __( 'Stats', 'behance-portfolio' ),
					)
				),
			)
		),
	);

	$options = apply_filters( 'wpbp_edit_plugin_options', $options );

	return $options;
}