<?php
/**
 * Behance Portfolio plugin for WordPress
 *
 * @package     Behance Portfolio
 * @author      ThemeAvenue <web@themeavenue.net>
 * @license     GPL-2.0+
 * @link        http://themeavenue.net
 * @copyright   2014 ThemeAvenue
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

add_filter( 'admin_footer_text', 'wpbp_version_in_footer' );
/**
 * Add version number in footer
 *
 * @since 1.0
 * @return string
 */
function wpbp_version_in_footer( $text ) {

	$pages = array( 'wpbp-settings', 'wpbp-about', 'wpbp-docs', 'wpbp' );

	if ( isset( $_GET['page'] ) && in_array( $_GET['page'], $pages ) ) {
		$text = sprintf( 'Behance Portfolio version %s by <a href="http://themeavenue.net">ThemeAvenue</a>.', WPBP_VERSION );
	}

	return $text;

}

add_action( 'admin_init', 'wpbp_dismiss_notice' );
/**
 * Dismiss license notice
 *
 * Set the notification as dismissed in the DB so that
 * it doesn't appear anymore even if the user doesn't
 * set his license number.
 *
 * @since 1.0.1
 */
function wpbp_dismiss_notice() {

	if ( isset( $_GET['wpbp-dismiss'] ) && 'true' == $_GET['wpbp-dismiss'] && isset( $_GET['wpbp'] ) ) {

		/* Saved notice as dismissed */
		if ( wp_verify_nonce( sanitize_key( $_GET['wpbp'] ), 'wpbp-dismiss' ) ) {

			/* Mark as dismissed */
			update_option( '_wpbp_dismissed', 'yes' );

			/* Prepare redirect URL */
			$current = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
			$current = explode( '?', $current );
			$base    = $current[0];
			$args    = $_GET;

			/* Remove unwanted URL vars */
			unset( $args['wpbp-dismiss'] );
			unset( $args['wpbp'] );

			/* Built redirect URL */
			$redirect = add_query_arg( $args, $base );

			/* Finally redirect with a clean URL */
			wp_redirect( $redirect );
			exit;

		}

	}

}

add_action( 'admin_notices', 'wpbp_license_notice' );
/**
 * Display notice if user didn't set his Envato license code
 *
 * @since 1.0.0
 * @return void
 */
function wpbp_license_notice() {

	$license   = wpbp_get_option( 'wpbp_license', false );
	$dismissed = get_option( '_wpbp_dismissed', 'no' );

	if ( $license || 'yes' == $dismissed ) {
		return;
	}

	/* Prepare the dismiss URL */
	$args                 = $_GET;
	$args['wpbp-dismiss'] = 'true';
	$url                  = wp_nonce_url( add_query_arg( $args, '' ), 'wpbp-dismiss', 'wpbp' ); ?>

	<div class="updated error">
		<p><?php printf( __( 'Please %sinsert your Envato license code%s now. If you don\'t, your copy of the plugin <strong>will never be updated</strong>.', 'wpbp' ), '<a href="' . admin_url( 'admin.php?page=wpbp-settings' ) . '">', '</a>' ); ?>
			<a href="<?php echo $url; ?>">
				<small>(<?php _e( 'I DO NOT want the updates, dismiss this message', 'behance-portfolio' ); ?>)</small>
			</a></p>
	</div>

<?php }

add_action( 'plugins_loaded', 'wpbp_remote_notices', 11 );
/**
 * Enable Remote Dashboard Notifications
 *
 * @since 1.0.0
 */
function wpbp_remote_notices() {

	/* Load RDN class */
	if ( ! class_exists( 'TAV_Remote_Notification_Client' ) ) {
		require_once( WPBP_PATH . 'includes/admin/class-remote-notification.php' );
	}

	/* Instantiate the class */
	new TAV_Remote_Notification_Client( 2, 'f5361a5fd26d2379', 'https://api.themeavenue.net?post_type=notification' );

}