<?php
/**
 * Behance Portfolio plugin for WordPress
 *
 * @package     Behance Portfolio
 * @author      ThemeAvenue <web@themeavenue.net>
 * @license     GPL-2.0+
 * @link        http://themeavenue.net
 * @copyright   2014 ThemeAvenue
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

add_shortcode( 'wpbp', 'wpbp_sc_portfolio' );
/**
 * Portfolio shortcode
 *
 * @param  array $atts Shortcode attributes
 *
 * @return string Markup
 */
function wpbp_sc_portfolio( $atts = array() ) {

	/**
	 * If the Behance API class is missing,
	 * no need ot go further.
	 */
	if ( ! class_exists( 'Behance\Client' ) ) {
		return false;
	}

	$username = trim( wpbp_get_option( 'behance_username' ) );
	$api_key  = trim( wpbp_get_option( 'behance_api_key' ) );

	/**
	 * Make sure we have the mandatory information
	 */
	if ( empty( $api_key ) || empty( $username ) ) {
		return '<!-- WPBP ERROR: Please setup your username, API key and API secret first. -->';
	}

	$def = array(
		'layout'          => wpbp_get_option( 'layout_archive', 'grid' ),
		'hover'           => wpbp_get_option( 'thumbnail_hover', '1' ),
		'button_label'    => wpbp_get_option( 'button_label', 'Take a look' ),
		'col_xs'          => wpbp_get_option( 'columns_xs', 1 ),
		'col_sm'          => wpbp_get_option( 'columns_sm', 2 ),
		'col_md'          => wpbp_get_option( 'columns_md', 4 ),
		'col_lg'          => wpbp_get_option( 'columns_lg', 6 ),
		'items_max'       => wpbp_get_option( 'items_max', 0 ),
		'filters'         => wpbp_get_option( 'filters', 'manual' ),
		'container_class' => '',
		'gutters'         => intval( wpbp_get_option( 'grid_gutters', 0 ) ),
		'elements'        => wpbp_get_option( 'items_elements', array() ),
		'delay_modal'     => false
	);

	$atts = shortcode_atts( $def, $atts );

	/* Turn on buffering */
	ob_start();

	/* Get the real gutters size */
	$gutters = $atts['gutters'] / 2;

	/* Automatically add the filters if an option is set */
	if ( 'manual' != $atts['filters'] ) {
		echo do_shortcode( '[wpbp-filters]' );
	}

	$main_container_class = apply_filters( 'wpbp_main_container_class', 'wpbp' );

	echo "<div class='$main_container_class'>";

	$grid_style = wpbp_get_option( 'thumbnail_hover', 1 );

	/* Prepare columns */
	$columns = array(
		"col-xs-{$atts['col_xs']}",
		"col-sm-{$atts['col_sm']}",
		"col-md-{$atts['col_md']}",
		"col-lg-{$atts['col_lg']}",
	);

	$elements = $atts['elements'];

	/* Make sure we have the correct format for $elements */
	if ( ! is_array( $elements ) ) {
		$elements = explode( ',', $atts['elements'] );
	}

	/* Prepare elements class */
	$class_subtitle = ( is_array( $elements ) && in_array( 'subtitle', $elements ) ) ? '' : 'wpbp-hidden';
	$class_tags     = ( is_array( $elements ) && in_array( 'tags', $elements ) ) ? '' : 'wpbp-hidden';
	$class_stats    = ( is_array( $elements ) && in_array( 'stats', $elements ) ) ? '' : 'wpbp-hidden';

	/* Set a counter */
	$count = 0;

	$columns  = implode( ' ', $columns );
	$items    = wpbp_get_items();
	$filename = "wpbp-{$atts['layout']}.php";
	$tpl      = locate_template( $filename, false );

	if ( '' == $tpl ) {

		if ( file_exists( WPBP_PATH . "templates/$filename" ) ) {
			$tpl = WPBP_PATH . "templates/$filename";
		} else {
			return;
		}

	}

	// Sanitize the button label
	$button_label = sanitize_text_field( $atts['button_label'] );

	if ( ! empty( $items ) ) {

		switch ( $atts['layout'] ):

			/**
			 * This is the grid layout
			 */
			case 'grid':

				$grid_wrapper_class = apply_filters( 'wpbp_grid_wrapper_class', array( 'grid', 'cs-style-' . $grid_style, 'wpbp-g-r' ) );
				$grid_wrapper_id    = apply_filters( 'wpbp_grid_wrapper_id', array( 'wpbp-grid' ) );

				// Add the grid wrapper
				printf( '<div class="%s" id="%s">', implode( ' ', $grid_wrapper_class ), implode( ' ', $grid_wrapper_id ) );

				foreach ( $items as $key => $item ) {

					$project = new WPBP_Project( $item['project_id'] );

					/**
					 * Get the project cover URL.
					 *
					 * @var (string)
					 */
					$project_cover = $project->get_cover();

					/* Limit the number of items if needed */
					if ( 0 != $atts['items_max'] && $count >= $atts['items_max'] ) {
						break;
					}

					$fields          = array();
					$creative_fields = $project->get_fields();

					if ( ! empty( $creative_fields ) ) {

						foreach ( $creative_fields as $id => $field ) {

							array_push( $fields, sanitize_title( $field ) );

						}

						$fields = implode( ' ', $fields );

					}

					require( $tpl );

					/* Increment the counter */
					$count ++;

				}

				echo '</div>';

				break;

			/**
			 * This is the slider layout
			 */
			case 'slider':

				$controls             = array();
				$thumbnail            = wpbp_get_option( 'slider_thumbnails', 'no' );
				$slider_wrapper_class = apply_filters( 'wpbp_slider_wrapper_class', array( 'wpbp-flexslider' ) );
				$slider_wrapper_id    = apply_filters( 'wpbp_slider_wrapper_id', array( 'wpbp-slider' ) );

				printf( '<div id="%s" class="%s"><div class="wpbp-slides">', implode( ' ', $slider_wrapper_id ), implode( ' ', $slider_wrapper_class ) );

				foreach ( $items as $key => $item ) {

					$project = new WPBP_Project( $item['project_id'] );
					$tags    = array();

					/* Limit the number of items if needed */
					if ( 0 != $atts['items_max'] && $count >= $atts['items_max'] ) {
						break;
					}

					/**
					 * Define control image
					 */
					array_push( $controls, '<li><img src="' . $project->get_cover() . '" class="img-responsive"/></li>' );

					/**
					 * Prepare tags
					 */
					foreach ( $project->get_tags() as $k => $tag ) {
						array_push( $tags, '<span class="wpbp-label">' . $tag . '</span>' );
					}

					/**
					 * Prepare creative fields
					 */
					if ( ! empty( $item->fields ) ) {

						foreach ( $item->fields as $id => $field ) {

							array_push( $fields, sanitize_title( $field ) );

						}

						$fields = implode( ' ', $fields );

					}

					require( $tpl );

					/* Increment the counter */
					$count ++;

				}

				echo '</div></div>';

				if ( is_array( $controls ) && ! empty( $controls ) && 'yes' == $thumbnail ) {

					$controls = implode( '', $controls );

					echo '<div id="wpbp-carousel" class="wpbp-flexslider"><ul class="wpbp-slides">';
					echo $controls;
					echo '</ul></div>';

				}

				break;

		endswitch;

	}

	echo '</div>';

	/* Add the projects details modal windows for grid layout */
	if ( 'grid' == $atts['layout'] ) {
		$_SESSION['wpas_modals'] = wpbp_details_modal();
	}

	/* Get the buffered content into a var */
	$sc = ob_get_contents();

	/* Clean buffer */
	ob_end_clean();

	/* Return the content as usual */

	return apply_filters( 'wpbp_sc_portfolio', $sc );

}