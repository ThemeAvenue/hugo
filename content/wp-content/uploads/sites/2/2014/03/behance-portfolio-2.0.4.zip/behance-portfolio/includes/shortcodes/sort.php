<?php
/**
 * Behance Portfolio plugin for WordPress
 *
 * @package   Behance Portfolio
 * @author 	  ThemeAvenue <web@themeavenue.net>
 * @license   GPL-2.0+
 * @link 	  http://themeavenue.net
 * @copyright 2014 ThemeAvenue
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

add_shortcode( 'wpbp-sort', 'wpbp_sc_sortable' );
/**
 * Add sorting options to the projects list
 *
 * @since 1.0
 *
 * @param array $atts Shortcode attributes
 *
 * @return string
 */
function wpbp_sc_sortable( $atts = array() ) {

	// Before anything else, we make sure the current layout is grid. Filters only work with the grid layout.
	if ( 'grid' !== wpbp_get_option( 'layout_archive', 'grid' ) ) {
		return '';
	}

	$defaults = array(
			'position' => wpbp_get_option( 'filters_position', 'left' ),
			'sortby'   => implode( ',', wpbp_get_option( 'sortable', array( 'date' ) ) ),
	);

	$atts   = shortcode_atts( $defaults, $atts );
	$sortby = $atts['sortby'];

	if ( empty( $sortby ) ) {

		return '';

	} else {

		$sortby = explode( ',', $sortby );

		if ( empty( $sortby ) || '' == $sortby ) {
			return '';
		}

	}

	$sc = '';
	$sc .= '<div class="wpbp">';
	$sc .= '<div class="wpbp-sortable">';
	$sc .= '<div class="wpbp-sort-controls wpbp-text-' . $atts['position'] . '">';

	if ( in_array( 'date', $sortby ) ) {

		$sc .= sprintf( '<button type="button" class="sort wpbp-label active" data-sort="data-pubdate" data-order="asc">%s</button>', esc_html_x( 'Date Asc', 'Display Behance projects by date from old to new', 'behance-portfolio' ) );
		$sc .= sprintf( '<button type="button" class="sort wpbp-label" data-sort="data-pubdate" data-order="desc">%s</button>', esc_html_x( 'Date Desc', 'Display Behance projects by date from new to old', 'behance-portfolio' ) );

	}

	if ( in_array( 'random', $sortby ) ) {
		$sc .= sprintf( '<button type="button" class="sort wpbp-label" data-sort="random">%s</button>', esc_html_x( 'Random', 'Display Behance projects in a random order', 'behance-portfolio' ) );
	}

	$sc .= '</div></div></div>';

	return $sc;

}