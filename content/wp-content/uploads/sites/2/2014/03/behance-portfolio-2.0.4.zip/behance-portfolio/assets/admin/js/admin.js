(function ($) {
	'use strict';

	$(function () {

		//////////////////////////////////////
		// ThemeAvenue Licence Validation //
		//////////////////////////////////////
		if ($('.tav-license').length > 0) {

			var tableLicense = $('.tav-license').parents('table').addClass('tav-license-table');
			var checkBtn = $('#tav-check-license');

			$('.tav-license').keypress(function (event) {

				var keycode = (event.keyCode ? event.keyCode : event.which);
				if (keycode == '13') {
					checkBtn.click();
					return false;
				}

			});

			checkBtn.on('click', function () {

				var submitBtn = $(this).addClass('tav-loading').blur();
				var data = {
					action: 'wpbp_check_license',
					license: $('.tav-license').val()
				};

				$.ajax({
					type: 'POST',
					url: ajaxurl,
					data: data,
					success: function (data) {
						submitBtn.removeAttr('disabled').removeClass('tav-loading');
						if (data === 'valid') {
							tableLicense.removeClass('tav-license-table-danger').addClass('tav-license-table-success');
							checkBtn.replaceWith('<span class="tav-license-btn-valid">&#x2714;</span>');
						} else if (data === 'empty') {
							tableLicense.removeClass('tav-license-table-success').addClass('tav-license-table-danger');
							tb_show(null, '#TB_inline?height=100&width=300&inlineId=tav-license-status-empty', null);
						} else {
							tableLicense.removeClass('tav-license-table-success').addClass('tav-license-table-danger');
							tb_show(null, '#TB_inline?height=100&width=300&inlineId=tav-license-status-error', null);
						}
					},
					error: function () {
						submitBtn.removeAttr('disabled').removeClass('tav-loading');
						tableLicense.removeClass('tav-license-table-success').addClass('tav-license-table-danger');
						tb_show(null, '#TB_inline?height=100&width=300&inlineId=tav-license-status-ajaxfail', null);
					}
				});

				return false;

			});
		}

		/////////////////////////////
		// WordPress Colorpicker //
		/////////////////////////////
		if (jQuery().wpColorPicker) {
			$('.tav-colorpicker').wpColorPicker();
		}

		//////////////////////////
		// WordPress Thickbox //
		// http://wordpress.stackexchange.com/questions/76358/how-to-use-thickbox-in-admin
		//////////////////////////
		if ($('.tav-trigger-modal').length > 0) {
			$('.tav-trigger-modal').on('click', function () {
				var url = $(this).attr('href');
				var title = $(this).attr('title');
				tb_show(title, url + '?TB_iframe=true');
				return false;
			});
		}

		////////////////////////////////
		// WordPress Media Uploader //
		////////////////////////////////
		if ($('.tav-file-upload').length > 0) {
			var _custom_media = true,
				_orig_send_attachment = wp.media.editor.send.attachment;

			$('.tav-file-upload-button').on('click', function (e) {

				e.preventDefault();

				var send_attachment_bkp = wp.media.editor.send.attachment;
				var button = $(this);
				var id = button.attr('id').replace('_upload', '');
				_custom_media = true;
				wp.media.editor.send.attachment = function (props, attachment) {
					if (_custom_media) {
						$('#' + id).val(attachment.url);
					} else {
						return _orig_send_attachment.apply(this, [props, attachment]);
					}
				};
				wp.media.editor.open(button);
				return false;
			});
			$('.add_media').on('click', function () {
				_custom_media = false;
			});
		}

		////////////////////////////////////////
		// Prevent multiple form submission //
		////////////////////////////////////////
		$('#wpbp-options-submit').on('click', function (event) {
			event.preventDefault();
			var formSubmit = $(this),
				form = formSubmit.parents('form'),
				formProgress = $('.wpbp-loading-modal'),
				itemsMax = $('#wpbp_items_max').val(),
				itemsCached = $('#wpbp-cached-items-number').val();
			console.log(itemsMax, itemsCached);
			formSubmit.val('Please wait...').prop('disabled', true);
			if (itemsMax !== itemsCached) {
				formProgress.show();
			}
			form.submit();
		});

	});

}(jQuery));