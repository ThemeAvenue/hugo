<?php
/**
 * Behance Portfolio plugin for WordPress
 *
 * @package   Behance Portfolio
 * @author 	  ThemeAvenue <web@themeavenue.net>
 * @license   GPL-2.0+
 * @link 	  http://themeavenue.net
 * @copyright 2014 ThemeAvenue
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

register_activation_hook( WPBP_PLUGIN_FILE, 'wpbp_install' );
/**
 * Plugin activation hook
 */
function wpbp_install() {

	/* Default options */
	$defaults = array(
		'behance_username'       => '',
		'behance_api_key'        => '',
		'wpbp_license'           => '',
		'cache'                  => 24,
		'items_max'              => 25,
		'logo'                   => '',
		'color_primary'          => '#00849c',
		'color_secondary'        => '#ffffff',
		'color_light'            => '#f5f5f5',
		'color_hover'            => '#f9bb22',
		'layout_archive'         => 'grid',
		'grid_gutters'           => 0,
		'filters'                => 'labels',
		'filters_position'       => 'center',
		'thumbnail_hover'        => 1,
		'button_label'           => __( 'View details', 'behance-portfolio' ),
		'popup_animation_in'     => 'fadeIn',
		'popup_animation_out'    => 'fadeOut',
		'slider_thumbnails'      => 'no',
		'slider_slideshow'       => 'yes',
		'slider_slideshow_speed' => 7000,
		'slider_animation'       => 'slide',
		'slider_pause'           => 'no',
		'items_elements'         => array( 'subtitle', 'tags' ),
		'behance_iframe'         => 'yes'
	);

	$options = get_option( 'wpbp_options' );

	/* Save default options */
	if( false === $options )
		update_option( 'wpbp_options', $defaults );

	/**
	 * Add an option in DB to know when the plugin has just been activated.
	 *
	 * @link http://stackoverflow.com/questions/7738953/is-there-a-way-to-determine-if-a-wordpress-plugin-is-just-installed/13927297#13927297
	 */
	add_option( 'wpbp_just_activated', true );

}