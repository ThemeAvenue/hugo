<?php
add_action( 'wp_ajax_wpbp_check_license', 'wpbp_ajax_check_license' );
/**
 * Use Ajax to check the Envato license.
 *
 * @return void
 */
function wpbp_ajax_check_license() {

	/**
	 * Set license key
	 *
	 * @var (string)
	 */
	$license = isset( $_POST['license'] ) ? trim( $_POST['license'] ) : '';

	$response = wpbp_check_envato_license( $license );

	if ( is_wp_error( $response ) ) {
		echo $response->get_error_message();
		die();
	} else {
		echo $response;
		die();
	}

}

/**
 * Check a Envato purchase code.
 *
 * @since 1.0.11
 *
 * @param string $license The license key to check
 * @param bool $sslverify Should the HTTP request verify local certificate
 *
 * @return string|WP_Error Whether or not the license is valid.
 */
function wpbp_check_envato_license( $license = '', $sslverify = true ) {

	global $wpbp_updater_config, $wp_version;

	/**
	 * Set license key
	 *
	 * @var string
	 */
	$license = isset( $_POST['license'] ) ? trim( filter_input( INPUT_POST, 'license', FILTER_SANITIZE_STRING ) ) : trim( $license );

	/**
	 * If the license is not set by the user,
	 * we return "empty".
	 */
	if ( empty( $license ) ) {
		return new WP_Error( 'empty_license', __( 'No license key to check passed to the function', 'behance-portfolio' ) );
	}

	/**
	 * Prepare the request arguments
	 *
	 * @var (array)
	 */
	$args = array(
		'timeout'    => 20,
		'body'       => array(
			'envato_license' => $license,
		),
		'user-agent' => 'WordPress/' . $wp_version,
		'sslverify'  => $sslverify
	);

	/**
	 * Get set request URL
	 *
	 * @var (string)
	 */
	$remote_url = add_query_arg( array( 'plugin_repo' => WPBP()->get_updater_config( 'repo_slug' ), 'ahr_check_envato_key' => true ), WPBP()->get_updater_config( 'repo_uri' ) );

	/**
	 * Query the server
	 */
	$raw_response = wp_safe_remote_post( $remote_url, $args );
	$body         = wp_remote_retrieve_body( $raw_response );

	if ( empty( $body ) ) {
		return new WP_Error( 'invalid_response', __( 'The server did respond but the response is invalid', 'behance-portfolio' ) );
	}

	return maybe_unserialize( $body );

}