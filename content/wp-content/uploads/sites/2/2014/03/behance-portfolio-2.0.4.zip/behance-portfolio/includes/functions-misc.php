<?php
/**
 * Behance Portfolio plugin for WordPress
 *
 * @package   Behance Portfolio
 * @author 	  ThemeAvenue <web@themeavenue.net>
 * @license   GPL-2.0+
 * @link 	  http://themeavenue.net
 * @copyright 2014 ThemeAvenue
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Help determine if the current page
 * belongs to the plugin.
 *
 * This function is used for "namespacing".
 * We try to keep the plugin resources and functions
 * only inside the plugin pages in order to avoid
 * conflicts with other plugins or themes.
 *
 * @package Behance Portfolio
 * @since   1.0.0
 */
function wpbp_is_plugin_page() {

	$pages = array(
		'wpbp-settings'
	);

	if ( isset( $_GET['page'] ) && in_array( $_GET['page'], $pages ) ) {
		return true;
	}

	return false;

}

/**
 * Get plugin option
 *
 * @param $option  string $option  Option requested
 * @param $default mixed $default Default value
 *
 * @return mixed          Option value
 * @since  1.0.0
 */
function wpbp_get_option( $option = '', $default = false ) {

	if ( empty( $option ) ) {
		return $default;
	}

	$options = get_option( 'wpbp_options', $default );

	if ( is_array( $options ) && isset( $options[ $option ] ) ) {
		return apply_filters( "wpbp_get_option_$option", $options[ $option ] );
	} else {
		return $default;
	}

}

/**
 * Compile all less files into one CSS
 *
 * @since 1.0.0
 */
function wpbp_compile_less() {

	/* Call the Behance API class */
	if ( ! class_exists( 'lessc' ) ) {
		require_once( WPBP_PATH . 'includes/lessc.inc.php' );
	}

	/* Load Uglify class */
	require_once( WPBP_PATH . 'includes/minify.php' );

	/* Prepare files paths */
	$input  = WPBP_PATH . 'assets/public/css/wpbp-variables.less';

	/* Instantiate the class */
	$less = new lessc;

	/* Define vars */
	$less->setVariables( array(
					"color-primary"   => ( $a = wpbp_get_option( 'color_primary', '#00a99d' ) ) != '' ? $a : '#00a99d',
					"color-secondary" => ( $b = wpbp_get_option( 'color_secondary', '#fff' ) ) != '' ? $b : '#fff',
					"color-light"     => ( $c = wpbp_get_option( 'color_light', '#efefef' ) ) != '' ? $c : '#efefef',
					"color-hover"     => ( $d = wpbp_get_option( 'color_hover', '#f9bf23' ) ) != '' ? $d : '#f9bf23',
			)
	);

	/* Compile and cache */
	$cache = $less->cachedCompile( $input );

	/* Minify the style */
	$minified = wpbp_minify( $cache['compiled'] );

	/* Save variable */
	update_option( 'wpbp_variable_style', $minified );

}