<?php
/**
 * Behance Portfolio plugin for WordPress
 *
 * @package     Behance Portfolio
 * @author      ThemeAvenue <web@themeavenue.net>
 * @license     GPL-2.0+
 * @link        http://themeavenue.net
 * @copyright   2014 ThemeAvenue
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

add_action( 'admin_init', 'wpbp_process_actions' );
/**
 * Process actions that can be triggered by $_GET or $_POST vars
 */
function wpbp_process_actions() {

	if ( isset( $_POST['wpbp-do'] ) ) {
		do_action( 'wpbp_' . $_POST['wpbp-do'], $_POST );
	}

	if ( isset( $_GET['wpbp-do'] ) ) {
		do_action( 'wpbp_' . $_GET['wpbp-do'], $_GET );
	}

}