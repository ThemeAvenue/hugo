Behance Portfolio
=================

Behance is a great service to showcase your work. However, if you have a personal or corporate site, you might also want to showcase your work. But who wants to work double by updating both Behance AND the WordPress site?

Thanks to Behance Portfolio for WordPress, the hassle is over. By using the Behance API, this plugin will gather your Behance projects and display them on your WordPress site.

**IMPORTANT**: This plugin requires cURL on your hosting server. It is active on most shared hosting, but you might want to check with the hosting provider first.

### Who is Behance Portfolio for?

Our plugin is designed for people who would like to showcase their Behance portfolio on their site or blog. This includes designers, agencies, freelancers, etc.

### Seamless integration

Behance Portfolio for WordPress has been designed to seamlessly integrate with any WordPress theme. Therefore, don’t worry about design compatibility. Your site will still look good, and so will the plugin! To avoid style conflicts, we used two techniques: we namespaced our stylesheet and used our own prefixes.

### Responsive &amp; Mobile-first

Because your theme is probably responsive, it wouldn't make sense if our plugin wasn't. Therefore, our responsive Behance Portfolio plugin was built with a priority for mobile. This means optimal performance on mobile devices.

### Easy to install

To get it working, it takes no more than 2 minutes. Once you've setup your **Behance username and API key**, you're pretty much good to go. The only thing to do is to insert the shortcode `[wpbp]` in your page. Read our quick start guide: http://support.themeavenue.net/plugins/behance-portfolio/documentation/

### Easy to customize

At this time, our plugin offers two layouts: **grid or slider**. Wether you're using one or the other, you can edit the color scheme yourself (using colorpickers). If you're a developer, you can go ahead and edit the different "templates" (grid / slider / details) and change its markup.

If you're using the grid layout, you can choose between **25+ animation for the popup** (when it appears and disappears).

### Robust and well maintained code

LESS preprocessor for a more maintainable and cleaner css. Autoprefixer. Settings API and WordPress best practices. Code maintained on BitBucket (already 124 commits as we speak).

### Built for performance

The plugin was coded in a way that impacts WordPress execution time very lightly. This is important as load speed matters both for your visitors and for search engines.

In order to gather your Behance projects, the plugin queries the Behance API. This can slow things down a lot. That's why **we integrated a caching system in the plugin**. Your site will only query Behance API every other day. You can even set the caching time yourself (24 hours by default). If you know you won't update your Behance portfolio everyday, you can set the cache at 3, 4, 7 days in just a second!

On the user side, we integrated automatic minification of the CSS that includes the basic CSS and the custom colors. This result in very few HTTP requests and super light stylesheets.

### Translation ready

We know our users come from all over the world. That's why we always localize our code. Doing it this way allows for very easy translation. The plugin is delivered with a translation catalog that enables you to start translating it in minutes.

#### Translators

* French (100%) - ThemeAvenue