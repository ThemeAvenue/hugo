<?php
/**
 * Plugin dashboard.
 *
 * @package   WP_Behance_Portfolio
 * @author    Julien Liabeuf <julien@liabeuf.fr>
 * @license   GPL-2.0+
 * @link      http://themeavenue.net
 * @copyright 2014 ThemeAvenue
 */
?>

<div class="wrap">  
	<div class="icon32" id="icon-options-general"></div>  
	<h2><?php _e( 'Behance Portfolio Settings', 'behance-portfolio' ); ?></h2>

	<?php
	if( isset( $_GET['settings-updated'] ) ) {

		?><div class="updated"><p><strong><?php _e( 'Settings updated successfully.', 'behance-portfolio' ); ?></strong> <?php printf( __( 'Copy/paste this shortcode in your portfolio page: %s', 'behance-portfolio' ), '<input type="text" id="wpbp-shortcode-copy" onmouseup="this.select();" readonly="readonly" value="[wpbp]" class="wp-ui-text-highlight code">' ); ?></p></div><?php

		/* Get items list */
		$items  = get_transient( '_wpbp_behance_items' );

		/* Get items number */
		$number = get_transient( '_wpbp_behance_items_number' );

		/* Check the limit and display a notice if limit is high */
		$limit = wpbp_get_option( 'items_max', 25 );

		if( false === $items || $number != $limit ):

			/* First we delete the items number transient which invalidates the cache */
			delete_transient( '_wpbp_behance_items_number' );

			/* Then delete the invalid cache */
			delete_transient( '_wpbp_behance_items' ); ?>

			<div class="updated error">
				<p><?php printf( __( 'When displaying lots of items (usually more than 25), the portfolio page can be long to load. However, we cache the results after the first visitor loaded the page in order to speed things up. If you don\'t want to wait for visitors and cache th results now, <a href="%s">please click here</a>.', 'behance-portfolio' ), admin_url( 'admin.php?page=wpbp-settings&amp;wpbp_cache=true' ) ); ?></p>
			</div>

		<?php endif;

	}

	if( isset( $_GET['wpbp_cached'] ) && 'true' == $_GET['wpbp_cached'] ) {

		?><div class="updated"><p><strong><?php _e( 'Your portfolio items were successfully cached.', 'behance-portfolio' ); ?></strong></p></div><?php

	}

	if( isset( $_GET['cleaned'] ) ) {

		if( 'true' == $_GET['cleaned'] ):

			?><div class="updated"><p><?php _e( 'The cache has been cleaned correctly.', 'behance-portfolio' ); ?></p></div><?php

		else:
			?><div class="updated"><p><?php _e( 'An error occured, the cache could not be cleaned completely.', 'behance-portfolio' ); ?></p></div><?php

		endif;
	}
	?>
	<p><?php _e( 'If you want to force the plugin to refresh the items details, you can empty the cache.', 'behance-portfolio' ); ?> <a href="<?php echo wp_nonce_url( add_query_arg( array( 'page' => 'wpbp-settings', 'empty_cache' => 'true' ), admin_url( 'admin.php' ) ), 'empty_cache', 'wpbpcache' ); ?>" class="button-secondary"><?php _e( 'Empty', 'behance-portfolio' ); ?></a></p>
	<form action="options.php" method="post" id="wpbp-settings-form">
		<?php
		settings_fields( 'wpbp_options' );
		do_settings_sections( 'wpbp_options' );
		?>
		<p class="submit">
			<input name="cached_items_number" type="hidden" id="wpbp-cached-items-number" value="<?php echo ( false === ( $number = get_transient( '_wpbp_behance_items_number' ) ) ) ? '' : $number; ?>">
			<input name="Submit" type="submit" class="button-primary" id="wpbp-options-submit" value="<?php _e( 'Save Changes', 'behance-portfolio' ); ?>" />
		</p>
		  
	</form>  
</div>

<div style="display: none;" class="wpbp-loading-modal">
	<div><?php _e( 'We\'re caching your portfolio items so that your visitors won\'t have to wait!', 'behance-portfolio' ); ?></div>
</div>