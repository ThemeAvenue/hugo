<div id="<?php echo $project->get_field( 'id' ); ?>" class="wpbp-u-1-3 wpbp-grid-col wpbp-mix <?php echo $fields; ?>" data-pubdate="<?php echo $project->get_field( 'published_on' ); ?>">
	<div style="padding: <?php echo $gutters; ?>px;">
		<figure>
			<a class="wpbp-project-imglink ta-modal-launch" href="#wpbp-project-<?php echo $project->get_field( 'id' ); ?>"><img src="<?php echo $project_cover; ?>" alt="<?php echo $project->get_field( 'name' ); ?>" class="img-responsive"></a>
			<figcaption>
				<div class="wpbp-valign">
					<div class="wpbp-valign-inner">
						<div class="wpbp-project-title"><?php echo $project->get_field( 'name' ); ?></div>
						<div class="wpbp-project-fields"><?php echo implode( ', ', $project->get_fields() ); ?></div>
						<a class="wpbp-project-more ta-modal-launch" href="#wpbp-project-<?php echo $project->get_field( 'id' ); ?>"><?php echo $button_label; ?></a>
					</div>
				</div>
			</figcaption>
		</figure>
	</div>
</div>