<?php
/**
 * Behance Portfolio plugin for WordPress
 *
 * @package     Behance Portfolio
 * @author      ThemeAvenue <web@themeavenue.net>
 * @license     GPL-2.0+
 * @link        http://themeavenue.net
 * @copyright   2014 ThemeAvenue
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Helper function to get a TLC transient
 *
 * This helper handles the expiration date based on the plugin settings.
 *
 * @param string $transient
 * @param string $update_callback
 * @param array  $args
 *
 * @return mixed
 */
function wpbp_get_transient( $transient, $update_callback, $args = array() ) {

	// Make sure the TLC Transients module is loaded
	if ( ! function_exists( 'tlc_transient' ) ) {
		require( WPBP_PATH . 'vendor/wp-tlc-transients/tlc-transients.php' );
	}

	$prefix         = 'wpbp_';
	$transient_name = $prefix . sanitize_text_field( $transient );
	$cache_hours    = wpbp_get_option( 'cache', 24 );
	$expires        = 60 * 60 * (int) $cache_hours;

	return tlc_transient( $transient_name )
			->updates_with( $update_callback, $args )
			->expires_in( $expires )
			->get();

}

/**
 * Clear all TLC transients
 *
 * This invalidates the cache and it will be regenerated during next call to the portfolio.
 *
 * @since 2.0
 * @return void
 */
function wpbp_clear_tlc_transients() {

	$items = wpbp_get_items();
	$key   = md5( 'wbpb_items' );

	if ( ! empty( $items ) ) {

		// First we clear each project transient one by one
		foreach ( $items as $item ) {

			$item_id   = $item['project_id'];
			$transient = md5( 'wpbp_project_' . $item_id );

			delete_transient( 'tlc__' . $transient );

		}

		// Then we clear the items transient
		delete_transient( 'tlc__' . $key );

	}

}

add_action( 'wpbp_reload_cache', 'wpbp_clear_tlc_transients' );
/**
 * Reload the portfolio cache
 *
 * @since 2.0
 * @return void
 */
function wpbp_reload_cache() {

	// Clear the cache
	wpbp_clear_tlc_transients();

	// Re-cache items
	wpbp_get_items();

	// Read-only redirect
	wp_redirect( admin_url( 'admin.php?page=wpbp-settings&wpbp_cached=true' ) );

}