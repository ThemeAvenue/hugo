<?php
/**
 * Behance Portfolio plugin for WordPress
 *
 * @package     Behance Portfolio
 * @author      ThemeAvenue <web@themeavenue.net>
 * @license     GPL-2.0+
 * @link        http://themeavenue.net
 * @copyright   2014 ThemeAvenue
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Retrieve Behance portfolio items
 *
 * Get Behance items and save the data in a
 * transient for a defined amount of time in order
 * to avoid a new query to Behance servers for every page load.
 *
 * @return array Items list
 * @since 1.0.0
 */
function wpbp_query_items() {

	if ( ! class_exists( 'Behance\Client' ) ) {
		return array();
	}

	$username = trim( wpbp_get_option( 'behance_username' ) );

	/**
	 * Set the maximum number of projects to retrieve.
	 *
	 * As of now, Behance API limits the number of items to 25.
	 * The plugin needs some extra coding in order to get other pages
	 * for users with more than 25 projects.
	 *
	 * @var integer
	 */
	$limit = wpbp_get_option( 'items_max', 25 );

	/* If limit is 0, it means user wants no limit, so let's set the max */
	if ( 0 == $limit ) {
		$limit = 25;
	}

	/**
	 * Get number of pages.
	 *
	 * Get the number of pages we have to query
	 * in order to get all projects.
	 *
	 * @var [type]
	 */
	$pages = floor( $limit / 25 );

	/**
	 * Get the number of remaining items.
	 *
	 * If the number of items is not a multiple of 25,
	 * we calculate the number of items to query on
	 * the last page.
	 *
	 * @var integer
	 */
	$remain = $limit - ( $pages * 25 );

	// Holds all our projects
	$items = array();

	/* If less than 25 items we only need one page */
	if ( 0 == $pages ) {
		$items = WPBP()->client()->getUserProjects( $username, array( 'per_page' => $limit ) );
	} else {

		$first = true;

		/* Get all pages with 25 projects */
		for ( $i = 1; $i <= $pages; $i ++ ) {

			$get = WPBP()->client()->getUserProjects( $username, array( 'per_page' => 25, 'page' => $i ) );

			/* First page doesn't need anything special */
			if ( $first ) {
				$items = $get;
				$first = false;
			} else {
				$items = wpbp_merge_pages( $items, $get, $i );
			}

		}

		/* Get the last incomplete page */
		if ( 0 != $remain ) {

			$get   = WPBP()->client()->getUserProjects( $username, array(
					'per_page' => $remain,
					'page'     => $pages + 1
			) );
			$items = wpbp_merge_pages( $items, $get, $i );

		}

	}

	// Now, because we manipulate individual projects with WPBP_Project() and that we never use the details
	// returned by the /projects endpoint, we only keep the projects IDs in order to not overload the database.
	// We just keep the fields that are used for filtering.

	$clean = array(); // This is where we store our projects IDs

	foreach ( $items as $key => $item ) {

		if ( ! is_object( $item ) ) {
			continue;
		}

		$project = array( 'project_id' => $item->id, 'tags' => array() );

		// Keep the project fields if any
		if ( isset( $item->fields ) && is_array( $item->fields ) && ! empty( $item->fields ) ) {

			$fields = array();

			foreach ( $item->fields as $field ) {

				$sanitized = sanitize_title( $field );

				if ( ! in_array( $sanitized, $fields ) ) {
					$fields[ $sanitized ] = $field;
				}

			}

			$project['tags'] = $fields;

		}


		array_push( $clean, $project );

	}

	return $clean;

}

/**
 * Get the Behance projects for the current account
 *
 * Wrapper function for wpbp_get_transient() with the transient name preset.
 *
 * @since 2.0
 * @return array
 */
function wpbp_get_items() {

	$items = wpbp_get_transient( 'items', 'wpbp_query_items' );

	if ( ! $items ) {
		$items = array();
	}

	return $items;

}

/**
 * Merge items pages.
 *
 * If the number of items if greater than 25,
 * we need to get multiple pages, then merge them
 * in order to cache and display all items.
 *
 * @since  1.0.6
 *
 * @param  array   $items List of items already retrieved
 * @param  array   $get   New page of items to merge
 * @param  integer $i     Page number
 *
 * @return array          List of items merged until page $i
 */
function wpbp_merge_pages( $items, $get, $i ) {

	/**
	 * Store the new items list.
	 *
	 * As we need to update the array indexes
	 * we need a fresh array.
	 *
	 * @var array Current page items
	 */
	$new = array();

	/**
	 * Last index used.
	 *
	 * We base the new array indexes on the last known index
	 * in order to successfully merge all pages.
	 *
	 * @var integer
	 */
	$last_idx = 25 * ( $i - 1 ) - 1;

	/* First we need to update the array indexes in order to avoid overwriting during merge */
	foreach ( $get as $index => $object ) {

		$last_idx ++;
		$new[ $last_idx ] = $object;

	}

	/* Merge existing items with current page items */

	return array_merge( $items, $new );

}

/**
 * Generate item modal content
 *
 * Generates the details modal popup content
 * for a specific portfolio item.
 *
 * @since 1.0.0
 * @return string Modal markup
 */
function wpbp_details_modal() {

	global $class_subtitle, $class_tags, $class_stats;

	$items = wpbp_get_items();

	if ( empty( $items ) ) {
		return '';
	}

	/* Turn on buffering */
	ob_start();

	foreach ( $items as $key => $item ):

		$project       = $project = new WPBP_Project( $item['project_id'] );
		$cover         = $project->get_cover();
		$views         = $project->get_views_count();
		$appreciations = $project->get_appreciations_count();
		$comments      = $project->get_comments_count();
		$tags          = array();
		$default       = WPBP_PATH . 'templates/wpbp-details.php';
		$tpl           = ( $t = locate_template( 'wpbp-details.php', false ) ) ? $t : $default;
		$details_link  = esc_url( $project->get_field( 'url' ) );

		foreach ( $project->get_tags() as $k => $tag ) {
			array_push( $tags, '<span class="wpbp-label">' . $tag . '</span>' );
		}

		require( $tpl );

	endforeach;

	/* Get the buffered content into a var */
	$modal = ob_get_contents();

	/* Clean buffer */
	ob_end_clean();

	/* Wrap the markup */
	$modal = "<div class='wpbp'>$modal</div>";

	/* Return the content as usual */

	return $modal;

}

/**
 * Check if an element should be displayed.
 *
 * @since  1.0.9
 *
 * @param  string $element Element to check
 *
 * @return boolean          Whether or not the element should be displayed
 */
function wpbp_has_element( $element ) {

	$elements = wpbp_get_option( 'items_elements', array() );

	return in_array( $element, $elements ) ? true : false;

}

/**
 * Retrieve all the tags used. The tags
 * are in fact the "creative fields" in Behance.
 *
 * @since 2.0
 * @return array List of tags
 */
function wpbp_get_all_tags() {

	$items = wpbp_get_items();
	$tags  = array();

	foreach ( $items as $key => $item ) {

		if ( isset( $item['tags'] ) && is_array( $item['tags'] ) && ! empty( $item['tags'] ) ) {

			foreach ( $item['tags'] as $field ) {

				$sanitized = sanitize_title( $field );

				if ( ! isset( $tags[ $sanitized ] ) ) {
					$tags[ $sanitized ] = $field;
				}

			}

		}

	}

	return $tags;

}