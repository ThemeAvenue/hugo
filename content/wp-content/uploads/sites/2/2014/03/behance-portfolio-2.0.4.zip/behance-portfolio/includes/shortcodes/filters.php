<?php
/**
 * Behance Portfolio plugin for WordPress
 *
 * @package   Behance Portfolio
 * @author 	  ThemeAvenue <web@themeavenue.net>
 * @license   GPL-2.0+
 * @link 	  http://themeavenue.net
 * @copyright 2014 ThemeAvenue
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

add_shortcode( 'wpbp-filters', 'wpbp_sc_filters' );
/**
 * Filters Shortcode
 *
 * This shortcode will add a filter bar. The filters
 * can be of multiple types. This function will check
 * if tags are available, then wrap the filters in
 * a main div and finally call the appropriate
 * function to render the filters.
 *
 * @param array Shortcode attributes
 *
 * @return string The complete filters markup
 */
function wpbp_sc_filters( $atts = array() ) {

	// Before anything else, we make sure the current layout is grid. Filters only work with the grid layout.
	if ( 'grid' !== wpbp_get_option( 'layout_archive', 'grid' ) ) {
		return '';
	}

	$defaults = array(
			'position'  => wpbp_get_option( 'filters_position', 'right' ),
			'namespace' => true,
			'nav'       => wpbp_get_option( 'filters', 'manual' )
	);

	$atts = shortcode_atts( $defaults, $atts );
	$tags = wpbp_get_all_tags();

	if ( empty( $tags ) ) {
		return '';
	}

	$sc = '';

	if ( $atts['namespace'] ) {
		$sc .= '<div class="wpbp">';
	}

	$sc .= '<div class="wpbp-filters">';

	switch ( $atts['nav'] ):

		case 'labels':

			$sc .= '<div class="wpbp-text-' . $atts['position'] . '"><ul>';
			$sc .= '<li class="filter wpbp-label" data-filter="all">' . __( 'Show All', 'behance-portfolio' ) . '</li>';

			foreach ( $tags as $sanitized => $name ) {

				$sc .= '<li class="filter wpbp-label" data-filter="' . $sanitized . '">' . $name . '</li>';

			}

			$sc .= '</ul></div>';

			break;

		case 'select':

			$sc .= '<div class="clearfix"><select class="form-control wpbe-filter-select">';
			$sc .= '<option class="filter" data-filter="all">' . __( 'Show All', 'behance-portfolio' ) . '</option>';

			foreach ( $tags as $sanitized => $name ) {

				$sc .= '<option class="filter" data-filter="' . $sanitized . '">' . $name . '</option>';

			}

			$sc .= '</select></div>';

			break;

	endswitch;

	$sc .= '</div>';

	if ( $atts['namespace'] ) {
		$sc .= '</div>';
	}

	return $sc;

}