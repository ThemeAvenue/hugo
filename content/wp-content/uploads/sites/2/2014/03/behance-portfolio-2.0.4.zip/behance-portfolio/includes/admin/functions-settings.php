<?php
/**
 * Behance Portfolio plugin for WordPress
 *
 * @package     Behance Portfolio
 * @author      ThemeAvenue <web@themeavenue.net>
 * @license     GPL-2.0+
 * @link        http://themeavenue.net
 * @copyright   2014 ThemeAvenue
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

add_action( 'admin_init', 'wpbp_register_plugin_settings' );
/**
 * Register plugin settings
 *
 * This function dynamically registers plugin
 * settings based on the options provided in
 * includes/settings.php
 *
 * @since 1.0
 * @return void
 */
function wpbp_register_plugin_settings() {

	$settings = wpbp_get_plugin_options();

	register_setting( 'wpbp_options', 'wpbp_options' );

	foreach ( $settings as $key => $section ) {
		/* We add the sections and then loop through the corresponding options */
		add_settings_section( $section['id'], $section['title'], false, 'wpbp_options' );

		/* Get the options now */
		foreach ( $section['options'] as $k => $option ) {

			if ( ! isset( $option['desc'] ) ) {
				$option['desc'] = '';
			}
			if ( ! isset( $option['opts'] ) ) {
				$option['opts'] = array();
			}
			$field_args = array(
				'name'    => $option['id'],
				'title'   => $option['title'],
				'type'    => $option['type'],
				'desc'    => $option['desc'],
				'options' => $option['opts'],
				'group'   => 'wpbp_options'
			);

			add_settings_field( $option['id'], $option['title'], 'wpbp_output_settings_field', 'wpbp_options', $section['id'], $field_args );
		}
	}
}

/**
 * Calls field output function
 *
 * @since 1.0
 *
 * @param array $args Arguments list for this setting
 *
 * @return void
 */
function wpbp_output_settings_field( $args ) {
	wpbp_output_option( $args );
}

// Recompile the LESS stylesheet when options are saved
add_action( 'update_option_wpbp_options', 'wpbp_compile_less' );