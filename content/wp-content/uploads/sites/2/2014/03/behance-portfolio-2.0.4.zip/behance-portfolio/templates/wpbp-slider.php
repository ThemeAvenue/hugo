<div id="<?php echo $project->get_field( 'id' ); ?>" >
	<div class="wpbp-g-r">
		<div class="wpbp-u-2-5">
			<img src="<?php echo $project->get_cover(); ?>" alt="<?php echo $project->get_field( 'name' ); ?>" class="img-responsive">
		</div>
		<div class="wpbp-u-3-5">
			<div class="wpbp-slider-desc">
				<h2 class="wpbp-modal-title"><?php echo $project->get_field( 'name' ); ?></h2>
				<h4 class="<?php echo $class_subtitle; ?>"><?php echo implode( ', ', $project->get_fields() ); ?></h4>
				<hr>
				<p><?php echo $project->get_field( 'description', 'wp_kses_post' ); ?></p>
				<div class="<?php echo $class_tags; ?>">
					<h5><?php echo _e( 'Project tags:', 'behance-portfolio' ); ?></h5>
					<?php echo implode( ' ', $tags ) ; ?>
				</div>
				<hr>
				<a href="?project_preview=<?php echo $project->get_field( 'id' ); ?>" type="button" class="wpbp-btn btn-primary" target="_blank"><?php _e( 'View on Behance', 'behance-portfolio' ); ?></a>
				<div class="wpbp-slide-controls"><a href="#wpbp-prev" class="wpbp-prev" title="Previous">&lt;</a><a href="#wpbp-next" class="wpbp-next" title="Next">&gt;</a></div>
			</div>
		</div>
	</div>
</div>