<div class="ta-modal" id="wpbp-project-<?php echo $project->get_field( 'id' ); ?>" tabindex="-1" role="dialog" aria-hidden="true" style="display:none;">
	<div class="ta-modal-body">
		<div class="wpbp-g-r">
			<div class="wpbp-u-1-2">
				<img src="<?php echo $cover; ?>" alt="<?php echo $project->get_field( 'name' ); ?>" class="wpbp-modal-img img-responsive">
				<?php if ( wpbp_has_element( 'stats' ) ): ?>
					<div class="<?php echo $class_stats; ?>">
						<div class="wpbp-item-stat"><i class="wpbpicon-eye"></i> <?php printf( __( 'Views <strong>%d</strong>', 'behance-portfolio' ), $project->get_views_count() ); ?></div><!----><div class="wpbp-item-stat"><i class="wpbpicon-thumbs-up-alt"></i> <?php printf( __( 'Appreciations %s', 'behance-portfolio' ), "<strong>{$project->get_appreciations_count()} )</strong>" ); ?></div><!----><div class="wpbp-item-stat"><i class="wpbpicon-chat"></i> <?php printf( __( 'Comments %s', 'behance-portfolio' ), "<strong>{$project->get_comments_count()}</strong>" ); ?></div>
					</div>
				<?php endif; ?>
			</div>
			<div class="wpbp-u-1-2">
				<div class="ta-modal-desc">
					<h2 class="wpbp-modal-title"><?php echo $project->get_field( 'name' ); ?></h2>
					<?php if ( wpbp_has_element( 'subtitle' ) ): ?><h4 class="<?php echo $class_subtitle; ?>"><?php echo implode( ', ', $project->get_fields() ); ?></h4><?php endif; ?>
					<hr>
					<p><?php echo $project->get_field( 'description', 'wp_kses_post' ); ?></p>
					<?php if ( wpbp_has_element( 'tags' ) ): ?>
						<div class="<?php echo $class_tags; ?>">
							<h5><?php echo _e( 'Project tags:', 'behance-portfolio' ); ?></h5>
							<?php echo implode( ' ', $tags ) ; ?>
						</div>
					<?php endif; ?>
					<hr>
					<a href="<?php echo $details_link; ?>" class="wpbp-btn" target="_blank"><?php _e( 'View on Behance', 'behance-portfolio' ); ?></a>
				</div>
			</div>
		</div>
	</div>
	<div class="ta-modal-close" title="<?php _e( 'Close', 'behance-portfolio' ); ?>" aria-hidden="true">&times;</div>
</div>