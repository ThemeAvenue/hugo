<div class="wrap about-wrap">

	<h1>Welcome to Behance Portfolio</h1>

	<div class="about-text">Thank you for buying Behance Portfolio for WordPress.<br> This plugin was created by the folks at <a href="http://themeavenue.net/" target="_blank">ThemeAvenue</a>.</div>

	<div class="changelog">
		<div class="feature-section col two-col">
			<div>
				<h3>Showcase your Behance Portfolio on your WordPress site</h3>
				<p>Behance is a great service to showcase your work. However, if you have a personal or corporate site, you might also want to showcase your work. But who wants to work double by updating both Behance AND the WordPress site?</p>
				<p>Thanks to Behance Portfolio for WordPress, the hassle is over. By using the Behance API, this plugin will gather your Behance projects and display them on your WordPress site.</p>
				<h4>Who is Behance Portfolio for?</h4>
				<p>Our plugin is designed for people who would like to showcase their Behance portfolio on their site or blog. This includes designers, agencies, freelancers, etc.</p>
			</div>
			<div class="last-feature about-colors-img">
				<img src="//i.imgur.com/ucMnxSX.png">
			</div>
		</div>
	</div>

	<hr>

	<div class="changelog">
		<div class="feature-section col three-col about-updates">
			<div class="col-1">
				<img src="//i.imgur.com/9OvhQgK.png">
				<h3>Easy to install</h3>
				<p>To get it working, it takes no more than 2 minutes. Once you've setup your <strong>Behance username and API key</strong>, you're pretty much good to go. The only thing to do is to insert the shortcode <code>[wpbp]</code> in your page. <a href="<?php echo admin_url( 'admin.php?page=wpbp-docs' ); ?>">Read our quick start guide</a></p>
			</div>
			<div class="col-2">
				<img src="//i.imgur.com/TxxqE6b.png">
				<h3>Responsive &amp; Mobile-first</h3>
				<p>Because your theme is probably responsive, it wouldn't make sense if our plugin wasn't. Therefore, our responsive Behance Portfolio plugin was built with a priority for mobile. This means optimal performance on mobile devices.</p>
			</div>
			<div class="col-3 last-feature">
				<img src="//i.imgur.com/sANW0Ms.png">
				<h3>Robust and well maintained code</h3>
				<p>LESS preprocessor for a more maintainable and cleaner css. Autoprefixer. Settings API and WordPress best practices. Code maintained on BitBucket (already 124 commits as we speak).</p>
			</div>
		</div>
	</div>

	<hr>

	<div class="changelog about-twentyfourteen">
		<div class="feature-section col one-col center-col">
			<div>
				<h3>Want to hear more about ThemeAvenue?</h3>
				<p><a href="http://themeavenue.net/" target="_blank">ThemeAvenue</a> is a premium WordPress themes and plugins development company. Feel free to check our portfolio on CodeCanyon and ThemeForest.</p>
				<a href="http://codecanyon.net/user/themeavenue"><img src="//i.imgur.com/fp5EbLk.jpg" alt="Follow us on Envato"></a>
				<a href="http://twitter.com/theme_avenue" target="_blank"><img src="//i.imgur.com/0WD80rt.jpg" alt="Follow us on Twitter"></a>
				<a href="https://www.facebook.com/pages/ThemeAvenue/461448310549015" target="_blank"><img src="//i.imgur.com/YRROCQm.jpg" alt="Join us on Facebook"></a>
				<a href="http://support.themeavenue.net/" target="_blank"><img src="//i.imgur.com/d8MN8xR.jpg" alt="ThemeAvenue Premium Support"></a>
			</div>
		</div>
	</div>

	<hr>

</div>