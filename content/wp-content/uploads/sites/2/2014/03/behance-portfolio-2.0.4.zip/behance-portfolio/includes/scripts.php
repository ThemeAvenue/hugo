<?php
/**
 * Behance Portfolio plugin for WordPress
 *
 * @package     Behance Portfolio
 * @author      ThemeAvenue <web@themeavenue.net>
 * @license     GPL-2.0+
 * @link        http://themeavenue.net
 * @copyright   2014 ThemeAvenue
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

add_action( 'wp_print_scripts', 'wpbp_load_scripts', 10, 0 );
/**
 * Enqueue front-end scripts
 *
 * @since 2.0
 * @return void
 */
function wpbp_load_scripts() {

	wp_register_script( 'wpbp-main', WPBP_URL . 'assets/public/js/wpbp.min.js', array( 'jquery' ), WPBP_VERSION, true );

	if ( ! is_admin() ) {
		wp_enqueue_script( 'wpbp-main' );
	}

}

add_action( 'wp_print_scripts', 'wpbp_localize_scripts', 11, 0 );
/**
 * Add required JS objects
 *
 * @since 2.0
 * @return void
 */
function wpbp_localize_scripts() {

	$object = array(
		'anim'   => array(
			'entrance' => wpbp_get_option( 'popup_animation_in', 'bounceIn' ),
			'exit'     => wpbp_get_option( 'popup_animation_out', 'bounceOut' ),
		),
		'slider' => array(
			'slideshow'       => ( 'yes' == wpbp_get_option( 'slider_slideshow', 'no' ) ) ? true : false,
			'slideshow_speed' => wpbp_get_option( 'slider_slideshow_speed', 7000 ),
			'animation'       => wpbp_get_option( 'slider_animation', 'slide' ),
			'pause'           => ( 'yes' == wpbp_get_option( 'slider_pause', 'yes' ) ) ? true : false,
		)
	);

	wp_localize_script( 'wpbp-main', 'wpbp', json_encode( $object ) );

}

add_action( 'wp_print_styles', 'wpbp_load_styles' );
/**
 * Enqueue front-end styles
 *
 * @since 2.0
 * @return void
 */
function wpbp_load_styles() {

	wp_register_style( 'wpbp-main', WPBP_URL . 'assets/public/css/wpbp.min.css', false, WPBP_VERSION, 'all' );

	if ( ! is_admin() ) {

		wp_enqueue_style( 'wpbp-main' );

		/* Get variable style from DB */
		$variable = get_option( 'wpbp_variable_style', false );

		/* If no style generated yet we do it now */
		if ( false === $variable || '' == $variable ) {
			$variable = wpbp_compile_less();
		}

		/* Add extra style to main */
		wp_add_inline_style( 'wpbp-main', $variable );

	}

}

add_action( 'wp_footer', 'wpbp_output_modals' );
/**
 * Output modal dialogs.
 *
 * We output the modal dialogs in the footer
 * in order ot avoid having them in the content
 * inside an element with a z-index to low.
 *
 * @since  1.0.5
 */
function wpbp_output_modals() {

	if ( isset( $_SESSION['wpas_modals'] ) ) {
		echo $_SESSION['wpas_modals'];
		unset( $_SESSION['wpas_modals'] );
	}

}


add_action( 'admin_enqueue_scripts', 'wpbp_enqueue_admin_styles' );
/**
 * Register and enqueue admin-specific style sheet.
 *
 * @since     1.0.0
 *
 * @return    void
 */
function wpbp_enqueue_admin_styles() {

	wp_register_style( 'wpbp-admin-docs', WPBP_URL . 'assets/admin/css/docs.css', null, WPBP_VERSION, 'all' );
	wp_register_style( 'wpbp-admin-styles', WPBP_URL . 'assets/admin/css/admin.css', null,WPBP_VERSION, 'all' );

	if ( isset( $_GET['page'] ) && 'wpbp-docs' === $_GET['page'] ) {
		wp_enqueue_style( 'wpbp-admin-docs' );
	}

	if ( isset( $_GET['page'] ) && 'wpbp-settings' === $_GET['page'] ) {
		wp_enqueue_style( 'wpbp-admin-styles' );
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_style( 'thickbox' );
	}

}

add_action( 'admin_enqueue_scripts', 'wpbp_enqueue_admin_scripts' );
/**
 * Register and enqueue admin-specific JavaScript.
 *
 * @since     1.0.0
 *
 * @return    void
 */
function wpbp_enqueue_admin_scripts() {

	wp_register_script( 'wpbp-admin-docs', WPBP_URL . 'assets/admin/js/docs.js', array( 'jquery' ), WPBP_VERSION );
	wp_register_script( 'wpbp-admin-script', WPBP_URL . 'assets/admin/js/admin.js', array( 'wp-color-picker' ), WPBP_VERSION );

	if ( isset( $_GET['page'] ) && 'wpbp-docs' === $_GET['page'] ) {
		wp_enqueue_script( 'wpbp-admin-docs' );
	}

	if ( isset( $_GET['page'] ) && 'wpbp-settings' === $_GET['page'] ) {
		wp_enqueue_script( 'wpbp-admin-script' );
		wp_enqueue_script( 'thickbox' );
		wp_enqueue_media();
	}

}