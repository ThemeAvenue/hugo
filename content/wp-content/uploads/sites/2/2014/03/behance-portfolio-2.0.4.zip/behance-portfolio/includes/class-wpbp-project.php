<?php
/**
 * Behance Portfolio plugin for WordPress
 *
 * @package     Behance Portfolio
 * @author      ThemeAvenue <web@themeavenue.net>
 * @license     GPL-2.0+
 * @link        http://themeavenue.net
 * @copyright   2014 ThemeAvenue
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Retrieve a Behance project using the API
 *
 * This function is only used to update the project transient
 *
 * @since 2.0
 *
 * @param int $project_id
 *
 * @return bool|object
 */
function wpbp_query_project( $project_id ) {
	return WPBP()->client()->getProject( $project_id );
}

class WPBP_Project {

	/**
	 * Our Behance project
	 *
	 * @since 2.0
	 * @var object
	 */
	public $project;

	/**
	 * The ID of the requested project
	 *
	 * @since 2.0
	 * @var int
	 */
	private $project_id;

	/**
	 * WPBP_Project constructor.
	 *
	 * @param int $project_id
	 */
	public function __construct( $project_id ) {
		$this->project_id = (int) $project_id;
	}

	/**
	 * Get the Behance project
	 *
	 * The project is retrieved from the cache using TLC Transients
	 *
	 * @since 2.0
	 * @link  https://github.com/markjaquith/WP-TLC-Transients
	 * @return object
	 */
	public function project() {

		if ( empty( $this->project ) ) {
			$this->project = wpbp_get_transient( 'project_' . $this->project_id, 'wpbp_query_project', array( 'project_id' => $this->project_id ) );
		}

		return $this->project;

	}

	/**
	 * Return the project cover image URL.
	 *
	 * @since  2.0
	 *
	 * @param string $size Cover size requested. Note that the size is a string and not an integer
	 *
	 * @return string
	 */
	public function get_cover( $size = '404' ) {

		$cover_sizes = array( '404', '230', '202', '115' );

		// If the requested size doesn't exist we fall back to 404
		if ( ! in_array( $size, $cover_sizes ) ) {
			$size = apply_filters( 'wpbp_default_cover_size', '404' );
		}

		/**
		 * Define $project_cover to avoid issues if no
		 * cover is found in the $item->covers object.
		 *
		 * @since  1.0.7
		 * @var    null
		 */
		$project_cover = null;

		/**
		 * Get the project cover URL.
		 *
		 * @var (string)
		 */
		if ( isset( $this->project()->covers->{$size} ) ) {

			$project_cover = $this->project()->covers->{$size};

		} else {

			foreach ( $cover_sizes as $next_biggest ) {

				if ( $size != $next_biggest && isset( $this->project()->covers->{$next_biggest} ) ) {

					$project_cover = $this->project()->covers->{$next_biggest};
					break;

				}

			}

		}

		/**
		 * Fallback for cover issues.
		 *
		 * In some cases the server can't retrieve the value
		 * for the requested cover. This appears to be due
		 * to the "numeric" key.
		 *
		 * Even using $item->covers->{$cover_size} do not seem to fix it.
		 *
		 * @link http://stackoverflow.com/questions/11515536/php-array-with-numeric-keys-as-string-cant-be-used
		 */
		if ( null === $project_cover ) {

			$covers = (array) $this->project()->covers;

			foreach ( $covers as $key => $cover ) {
				if ( $size == $key ) {
					$project_cover = $cover;
				}
			}

		}

		return $project_cover;

	}

	/**
	 * Get the project creative fields
	 *
	 * @since 2.0
	 * @return array
	 */
	public function get_fields() {

		$fields = array();

		if ( isset( $this->project()->fields ) && is_array( $this->project()->fields ) ) {
			$fields = $this->project()->fields;
		}

		return $fields;

	}

	/**
	 * Get the project tags
	 *
	 * @since 2.0
	 * @return array
	 */
	public function get_tags() {

		$tags = array();

		if ( isset( $this->project()->tags ) && is_array( $this->project()->tags ) ) {
			$tags = $this->project()->tags;
		}

		return $tags;

	}

	/**
	 * Get the project views
	 *
	 * @since 2.0
	 * @return int
	 */
	public function get_views_count() {

		$views = 0;

		if ( isset( $this->project()->stats->views ) ) {
			$views = (int) $this->project()->stats->views;
		}

		return $views;

	}

	/**
	 * Get the project appreciations
	 *
	 * @since 2.0
	 * @return int
	 */
	public function get_appreciations_count() {

		$views = 0;

		if ( isset( $this->project()->stats->appreciations ) ) {
			$views = (int) $this->project()->stats->appreciations;
		}

		return $views;

	}

	/**
	 * Get the project comments
	 *
	 * @since 2.0
	 * @return int
	 */
	public function get_comments_count() {

		$views = 0;

		if ( isset( $this->project()->stats->comments ) ) {
			$views = (int) $this->project()->stats->comments;
		}

		return $views;

	}

	/**
	 * Try and get a random field value
	 *
	 * If the requested field exists in the project object we return its value.
	 * Otherwise we return an empty string.
	 *
	 * @param string $field
	 * @param string $sanitize_callback Name of a function to use for sanitizing the field value. Set to false for no
	 *                                  sanitization
	 *
	 * @return mixed string
	 */
	public function get_field( $field, $sanitize_callback = 'sanitize_text_field' ) {

		$value = '';

		if ( isset( $this->project()->$field ) ) {
			$value = $this->project()->$field;
		}

		// Sanitize the value if the callback exists and isn't set to false
		if ( $sanitize_callback && function_exists( $sanitize_callback ) ) {
			call_user_func( $sanitize_callback, $value );
		}

		return $value;

	}

}