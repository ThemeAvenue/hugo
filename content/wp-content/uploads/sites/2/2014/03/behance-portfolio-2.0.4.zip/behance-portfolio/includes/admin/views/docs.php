<div class="wrap about-wrap">

	<h1>Documentation</h1>

	<div class="about-text">Thank you very much for purchasing our Behance Portfolio WordPress plugin. We hope that this product will give you entire satisfaction.</div>
	<p>If you are thinking about a new feature you would like to see or if you think you spotted a bug, please <a title="Behance Portfolio Roadmap" href="https://trello.com/b/YwWTDiN7" target="_blank">head to our roadmap</a> first and check what’s currently going on with the development.</p>

	<hr>

	<div id="ta-summary"><ol></ol></div>

	<h2>Installing the plugin</h2>
	<p>After you purchased and downloaded the plugin from CodeCanyon, you will have to install it on your WordPress site. In order to do that, please follow the steps described in our FAQ article “<a href="http://support.themeavenue.net/faqs/how-to-install-a-plugin/"
		target="_blank">How to install a plugin</a>“.</p>
		<h2>Activating the updates</h2>
		<p>If you want to benefit from the plugin auto update feature, you will have to activate it by providing your Envato purchase code. If you don’t know how to get your purchase code, <a href="http://support.themeavenue.net/faqs/get-envato-purchase-code/"
			target="_blank">please watch this video</a>.</p>
			<p>
				<a href="http://support.themeavenue.net/wp-content/uploads/2014/03/activation1.jpg">
					<img class="aligncenter size-full wp-image-13288" alt="activation" src="http://support.themeavenue.net/wp-content/uploads/2014/03/activation1.jpg" width="899" height="150">
				</a>
			</p>
			<div class="zilla-alert yellow">If you DO NOT activate the plugin, you will still be able to use 100% of its features, but you will NOT get the automatic updates.</div>
			<p>If you want to know why you need to activate the product, <a title="Why you Need to Validate the Product" href="http://support.themeavenue.net/product-validation/" target="_blank">we explained everything on this page</a>.</p>
			<h2>Linking to a Behance Account</h2>
			<p>After you have installed and activated the plugin, you will need to link it to your Behance account in order for it to get your projects. This will be done in 2 simple steps.</p>
			<h3>Registering a new application</h3>
			<p>Register a new application in your Behance account. <a href="https://www.behance.net/dev/register" target="_blank">You can follow this link</a> to directly reach the registration page.</p>
			<p>You should then see a page that looks like the one in the screenshot hereafter.</p>
			<p>
				<a href="http://support.themeavenue.net/wp-content/uploads/2014/03/register-app.jpg">
					<img class="aligncenter size-full wp-image-13271" alt="register-app" src="http://support.themeavenue.net/wp-content/uploads/2014/03/register-app.jpg" width="649" height="709">
				</a>
			</p>
			<p>&nbsp;</p>
			<p>Once you have hit the “Register Your App” button, you’ll be redirected to a new screen that shows your API Key. This is what the plugin needs in order to authenticate the requests made on your Behance account. You can always see the API key by clicking
				the “<a href="https://www.behance.net/dev/apps" target="_blank">Manage Your Apps</a>” link in the left hand menu.</p>
				<p>
					<a href="http://support.themeavenue.net/wp-content/uploads/2014/03/api-key.jpg">
						<img class="aligncenter size-full wp-image-13273" alt="api-key" src="http://support.themeavenue.net/wp-content/uploads/2014/03/api-key.jpg" width="780" height="357">
					</a>
				</p>
				<h2>Displaying the portfolio</h2>
				<p>As the plugin comes with predefined settings, once all the above steps are completed, the plugin is ready to work. The only thing you need to do is to place the portfolio shortcode where you want your portfolio to appear.</p>
				<p>You can use the shortcode in a page, in a post, or in any custom post type. Basically, anywhere the shortcodes are supported.</p>
				<h3>Shortcode</h3>
				<p>The shortcode you’ll need to use is <code>[wpbp]</code>. When viewing a page with this shortcode, it will immediately be replaced by your Behance items.</p>
				<h3>Options</h3>
				<p>The shortcode has various options available. Basically, all the options you can see in the “Layout &amp; Style” section of the plugin settings page can be overwritten by shortcode options.</p>
				<p>If you want to manually add options to the shortcode, you have to respect the following pattern: <code>[wpbp option="value"]</code>.</p>
				<p>Here is the list of options available:</p>
				<ul>
					<li><strong>layout</strong>:<strong>&nbsp;</strong>t<span style="line-height: 1.5em;">he desired layout for this portfolio.</span>
						<ul>
							<li><strong style="line-height: 1.5em;">Options</strong><span style="line-height: 1.5em;">: grid, slider</span>
							</li>
							<li><strong style="line-height: 1.5em;">Default</strong><span style="line-height: 1.5em;">: grid</span>
							</li>
						</ul>
					</li>
					<li><span style="line-height: 1.5em;"><strong>hover</strong>: Desired effect on mouse hover. The list of available effects can be seen in the plugin settings page.</span>
						<ul>
							<li><strong>Options</strong>: see available effect in plugin settings page</li>
							<li><strong>Default</strong>: 1</li>
						</ul>
					</li>
					<li><span style="line-height: 1.5em;"><strong>button_label</strong>: Text displayed on the button your visitors click to see more details about a project.</span>
						<ul>
							<li><strong>Options</strong>: any text string</li>
							<li><strong>Default</strong>:&nbsp;Take a look</li>
						</ul>
					</li>
					<li><span style="line-height: 1.5em;"><strong>items_max</strong>: Maximum number of items to display in this portfolio.</span>
						<ul>
							<li><strong>Options</strong>: any numeric value</li>
							<li><strong>Default</strong>: 0 (unlimited)</li>
						</ul>
					</li>
					<li><span style="line-height: 1.5em;"><strong>filters</strong>: Type of filters you want to show above the portfolio items. You you select “manual” you can manually place the filters using the <code>[wpbp-filters]</code> shortcode.</span>
						<ul>
							<li><span style="line-height: 1.5em;"><strong>Options</strong>: labels, select or manual</span>
							</li>
							<li><strong>Default</strong>: manual</li>
						</ul>
					</li>
					<li><span style="line-height: 1.5em;"><strong>container_class</strong>: A custom class that you might want to add to the portfolio container.</span>
						<ul>
							<li><strong>Options</strong>: any CSS class</li>
							<li><strong>Default</strong>: none</li>
						</ul>
					</li>
					<li><span style="line-height: 1.5em;"><strong>gutters</strong>: Size in pixels of the gutters if you want to add any.</span>
						<ul>
							<li><strong>Options</strong>: any numeric value</li>
							<li><strong>Default</strong>: 0</li>
						</ul>
					</li>
					<li><span style="line-height: 1.5em;"><strong>elements</strong>: Elements to show on the item details.</span>
						<ul>
							<li><span style="line-height: 1.5em;"><strong>Options</strong>: subtitle, tags, stats</span>
							</li>
							<li><strong>Default</strong>: subtitle, tags</li>
						</ul>
					</li>
				</ul>
				<h4>Examples</h4>
				<p>Display a portfolio with 6 items, use a select for the filters and only display the tags: <code>[wpbp items_max="6" filters="select" elements="tags"]</code>
				</p>
				<p>Display a portfolio slider with unlimited projects, no filters, the subtitle and tags&nbsp;<code>[wpbp filters="manual" layout="slider" elements="subtitle,tags"]</code>
				</p>
				<p>Please keep in mind that the shortcode parameters are most useful if you display multiple portfolios. If you only show one, I advise you use the settings in the plugin settings page as it is much easier.</p>
				<h2>Displaying filters</h2>
				<p>If you want to have more control on your layout and manually place the filters, you will have to set the filters as “manual” either in the plugin settings or through a shortcode parameter.</p>
				<p>Then, you have to place the shortcode <code>[wpbp-filters]</code> where you want it to be displayed in your page.</p>
				<p>This shortcode takes two parameters (if you want to know how to use shortcode parameters please refer to the previous chapter):</p>
				<ul>
					<li><strong>position</strong>: The alignment of your filters.
						<ul>
							<li><strong>Options</strong>: left, center, right, justified</li>
							<li><strong>Default</strong>: center</li>
						</ul>
					</li>
					<li><strong>nav</strong>: The type of filters to diaplay.
						<ul>
							<li><strong>Options</strong>: labels, select</li>
							<li><strong>Default</strong>: labels</li>
						</ul>
					</li>
				</ul>
				<h4>Example</h4>
				<p>Display the filters as labels and align them on the right of the page <code>[wpbp-filters nav="labels" position="right"]</code>
				</p>
				<h2>Displaying sorting options</h2>
				<p>If you want to give your visitors the possibility to sort your projects, you will have to place the shortcode <code>[wpbp-sort]</code> where you want it to appear in your page.</p>
				<p>This shortcode takes two parameters&nbsp;(if you want to know how to use shortcode parameters please refer to chapter “Displaying the portfolio”):</p>
				<ul>
					<li><strong>position</strong>:&nbsp;The alignment of your sorting options.
						<ul>
							<li><strong>Options</strong>: left, center, right, justified</li>
							<li><strong>Default</strong>: center</li>
						</ul>
					</li>
					<li><strong>sortby</strong>: The sorting options.
						<ul>
							<li><strong>Options</strong>: date, random</li>
							<li><strong>Default</strong>: date</li>
						</ul>
					</li>
				</ul>
				<h4>Example</h4>
				<p>Let users sort the items by date or in random order and align the options on the left <code>[wpbp-sort position="left" sortby="date,random"]</code>
				</p>
				<h2>Customizing the templates</h2>
				<p>The plugin works with a templating system. All templates can be found in <code>/public/views/templates</code>
				</p>
				<p>This allows you to customize the following:</p>
				<ul>
					<li>Grid layout
						<ul>
							<li>The grid display: <code>wpbp-grid.php</code>
							</li>
							<li>The modal popup details: <code>wpbp-details.php</code>
							</li>
						</ul>
					</li>
					<li>Slider layout: <code>wpbp-slider.php</code>
					</li>
				</ul>
				<p>If you want to customize any of these templates, just copy and paste it in your theme’s root directory (it works with child themes also) and then change anything you want in the markup.</p>

			</div>